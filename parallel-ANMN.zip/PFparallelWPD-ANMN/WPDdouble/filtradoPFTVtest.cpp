//*************************************************************************
//    * CODIGO GPU *
//    Programa que resuelve el modelo para filtrado utilizando punto fijo
//    realiza K iteraciones de Gauss-Seidel
//
// Author       : Iván de Jesús May-Cen
// Language     : C++
// Compiler     : g++
// Environment  : 
// Revisions
//   Initial    : 2023-05-09 09:36:44 
//   Last       : 
//
//  para compilar
//    g++ -O2 -fopenmp filtradoANMNGPU.cu -o test_gpu -lrt -lblitz -lgomp `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//  para ejecutar
//    ./test_gpu
//  Paralelo usando GPU - CUDA:
//    nvcc -arch=compute_75 -Xcompiler `pkg-config --cflags --libs opencv` -I /usr/local/cuda-8.0/include/ -L /usr/local/cuda-8.0/lib64/ -lcuda -lcudart -lopencv_core -lopencv_highgui -lopencv_imgproc filtradoPFTVtest_GPU.cu filtradoPFTVtest.cpp -o test_gpu
//
//       VERSION SIN LA LIBRERIA BLITZ
//         09 / Mayo / 2023
//
//  Paralelo usando GPU - CUDA:
//    nvcc -arch=compute_75 -Xcompiler `pkg-config --cflags --libs opencv` -I /usr/local/cuda-8.0/include/ -L /usr/local/cuda-8.0/lib64/ -lcuda -lcudart -lopencv_core -lopencv_highgui -lopencv_imgproc filtradoPFTVtest_GPU.cu filtradoPFTVtest.cpp -o test_gpu
//
//  para ejecutar:
//    ./test ArchivoImagen.png
//    ./test wp480x640-ANMN-02.png
//
// 
//*************************************************************************

// preprocesor directives
#include <opencv2/core/core.hpp>                // OpenCV      
#include <opencv2/highgui/highgui.hpp>           
#include <sys/time.h>                   // funciones de tiempo
#include <cmath>                        // funciones matematicas
#include <float.h>                      // mathematical constants
#include <iostream>                                  
#include <fstream> 

//defines
#define Proc_GPU

#ifdef Proc_GPU
#include "filtradoPFTVtest_GPU.cuh"
#endif 

// declara namespace
using namespace std;
using namespace cv;


// parametros para funcional a utilizar en la optimizacion
const double lambda1 = 1.0;
const double lambda2 = 1.0;
const double lambda3 = 1.0;
const double lambda4 = 0.1;
const double lambda5 = 0.1;
const int TIPO = 9, K = 3; // 5
const double BETA = 1.0e-3, EPS0 = 0.01, EPS = sqrt(DBL_EPSILON);

// variables del metodo numerico
const double EPSILON1 = 1.0e-6;         // criterio de paro del algoritmo, gradiente
const double EPSILON2 = 1.0e-6;         // criterio de paro del algoritmo, cambio en x
const unsigned ITER_MAX1 = 200000;    // maximo de iteraciones 


  // datos de la imagen
  int renglones, columnas, N_T, N_threads = 2, ban_proc;
  //Variable global para fase ruidosa
  double* WP0, *sn0, *cs0; 

// declaracion de funciones
//double funcionPhase(double,double);
//void punto_Fijo_TV_ANMN( double* Is_h, double* Ic_h, double* Is1_h, double* Ic1_h );
//double Funcional( double* Is_h, double* Ic_h );
//double gradientWrap(double,double);
//double minMod(double,double);  
//void boundaryCond1( double* T, int renglones, int columnas );
//void boundaryCond1( double* T1, double* T2, int renglones, int columnas );
//void iteracion_Gauss_Seidel_RB(double* Ic_h, double* Is_h, double* Ic1_h, double* Is1_h, int R_B);
//void error_relativo(double* errorRe, double* errorIm, double* Re, double* Reo, double* Im, double* Imo);


//*************************************************************************
//
//                        inicia funcion principal
//
//*************************************************************************
int main( int argc, char **argv )
{

  char imgname[50];  //nombre de archivo para franjas con portadora
  //parametros desde consola
  if(argc == 2) 
    {
     // read name of the file, read image
     strcpy( imgname, argv[1] );
    }

  // despliega informacion del proceso
  cout << endl << "Inicia procesamiento..." << endl << endl;
  cout << endl << "Lee datos ruidosos..." << endl << endl;  

  // datos de la imagen
  Mat IMAGEN = imread(imgname, IMREAD_GRAYSCALE);
  if( !IMAGEN.data )
    {
      cout << "Error en la lectura de la imagen inicial..." << endl;
      return -1;
    }
  renglones = IMAGEN.rows, columnas = IMAGEN.cols;

 
  // Arreglos para calculos numericos
  double *Is_h, *Ic_h, *Is0_h, *Ic0_h, *Is1_h, *Ic1_h;
  long int size_matrix = renglones*columnas;
  size_t size_matrix_bytes = size_matrix * sizeof(double);
  Is_h = (double*)malloc(size_matrix_bytes);
  Ic_h = (double*)malloc(size_matrix_bytes);
  Is0_h = (double*)malloc(size_matrix_bytes);
  Ic0_h = (double*)malloc(size_matrix_bytes);  
  Is1_h = (double*)malloc(size_matrix_bytes);
  Ic1_h = (double*)malloc(size_matrix_bytes);  
  WP0 = (double*)malloc(size_matrix_bytes);  
  sn0 = (double*)malloc(size_matrix_bytes);
  cs0 = (double*)malloc(size_matrix_bytes);
 
//#ifdef Proc_GPU
  // memoria para GPU
  double *Is_dev, *Ic_dev, *Is0_dev, *Ic0_dev, *Is1_dev, *Ic1_dev, *WP0_dev, *sn0_dev, *cs0_dev;
  //long int size_matrix = renglones*columnas;
  //size_t size_matrix_bytes = size_matrix * sizeof(double);
  cudaMalloc((void **)&Is_dev, size_matrix_bytes);
  cudaMalloc((void **)&Ic_dev, size_matrix_bytes);
  cudaMalloc((void **)&Is0_dev, size_matrix_bytes);
  cudaMalloc((void **)&Ic0_dev, size_matrix_bytes);
  cudaMalloc((void **)&Is1_dev, size_matrix_bytes);
  cudaMalloc((void **)&Ic1_dev, size_matrix_bytes);
  cudaMalloc((void **)&WP0_dev, size_matrix_bytes);
  cudaMalloc((void **)&sn0_dev, size_matrix_bytes);
  cudaMalloc((void **)&cs0_dev, size_matrix_bytes);
  // Configuración de los tamaños de la malla y el bloque de hilos
  int max_ren_col = max(renglones, columnas);
  int grid_size_bCond = iDivUp(max_ren_col, BLOCKDIM_X);
  dim3 block_size_FPart(BLOCKDIM_X, BLOCKDIM_Y,1);
  dim3 grid_size_FPart(iDivUp(columnas - 2, BLOCKDIM_X), iDivUp(renglones - 2,BLOCKDIM_Y), 1);
  dim3 block_size_evalF(BLOCKDIM_X, BLOCKDIM_Y, 1);
  dim3 grid_size_evalF(iDivUp(columnas, BLOCKDIM_X), iDivUp(renglones, BLOCKDIM_Y), 1);
  long int grid_size_dif= iDivUp(size_matrix, BLOCKDIM_X_1D);

  //para la memoria compartida en cada bloque de hilos
  size_t smemSize_FuncPart = BLOCKDIM_X * BLOCKDIM_Y * sizeof(double);
  size_t smemSize_3        = 9 * BLOCKDIM_X_1D * sizeof(double);  //Hay que tener cuidado de no pasarnos de los 48KB
  size_t smemSize_4 = 4 * BLOCKDIM_X_1D_T * sizeof(double); //El tamaño de los hilos por bloque en este caso puede ser de 1024
	                                                         //Vamos a cambiar el BLOCKDIM_X_1D a 672  
  size_t smemSize_1        = 3 * BLOCKDIM_X_1D_T * sizeof(double);//Aquí no nos pasamos de los 48KB de memoria compartida
#ifdef atomics_GPU                                         
	size_t size_Sum_dif_3 = 3 * sizeof(double);
	size_t size_Sum_FuncPart = sizeof(double);
#else      //sin atomics usamos los cores del CPU para realizar la última parte de la sumatoria
	size_t size_Sum_dif_3 = 3 * grid_size_dif * sizeof(double);
	size_t size_Sum_FuncPart = grid_size_evalF.x * grid_size_evalF.y * sizeof(double);	
#endif

	//host memory
	double* Sum_FuncPart = (double*)malloc(size_Sum_FuncPart);
	double* Sum_pow2difP_pow2P_pow2P0 = (double*)malloc(size_Sum_dif_3);
	double* Sum_pow2difA_pow2A_pow2A0 = (double*)malloc(size_Sum_dif_3);
	double* Sum_pow2difB_pow2B_pow2B0 = (double*)malloc(size_Sum_dif_3);
	//Device memory
	double* Sum_FuncPart_dev;
	//cudaMalloc((void**)&Sum_FuncPart_dev, size_Sum_FuncPart);
    cudaMalloc((void**)&Sum_FuncPart_dev, sizeof(double));
	
    double *sum_pow2difRRo_dev,*sum_pow2Reo_dev,*sum_pow2difIIo_dev,*sum_pow2Imo_dev;

    cudaMalloc((void**)&sum_pow2difRRo_dev, sizeof(double));
    cudaMalloc((void**)&sum_pow2Reo_dev, sizeof(double));
    cudaMalloc((void**)&sum_pow2difIIo_dev, sizeof(double));
    cudaMalloc((void**)&sum_pow2Imo_dev, sizeof(double));
    
    /*double* Sum_pow2difP_pow2P_pow2P0_dev;
    double* Sum_pow2difA_pow2A_pow2A0_dev;
    double* Sum_pow2difB_pow2B_pow2B0_dev;
    cudaMalloc((void**)&Sum_pow2difP_pow2P_pow2P0_dev, size_Sum_dif_3);
	cudaMalloc((void**)&Sum_pow2difA_pow2A_pow2A0_dev, size_Sum_dif_3);
	cudaMalloc((void**)&Sum_pow2difB_pow2B_pow2B0_dev, size_Sum_dif_3);*/
  //#endif
//#endif // Proc_GPU



  
  // crea manejador de imagenes con openCV
//  Mat Imagen( renglones, columnas, CV_64F, (unsigned char*) dummy.data() );
//  const char *win0 = "Fase a recuperar";      namedWindow( win0, WINDOW_AUTOSIZE );
//  const char *win1 = "Estimaciones";          namedWindow( win1, WINDOW_AUTOSIZE );


  int tonos = 256; // tonos de gris
  double omega = 2.0 * M_PI / double(tonos);
  double LUT[tonos];
  for ( int x = 0; x < tonos; x++ )
    {
      double fase = omega*double(x+1) - M_PI;
      LUT[x] = atan2( sin(fase), cos(fase) );
    }

  // genera patrones de franjas
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // genera patrones de franjas con ruido
        //double ruido = factor*ruidoImagen.random();
        // Lee valores desde imagen
        double Phase = LUT[IMAGEN.at<unsigned char>(r,c)];
        int idx_r_c = r*columnas + c;
       
        // arreglos con datos de sin y cos de fase ruidosa      
        sn0[idx_r_c] = sin(Phase);
        cs0[idx_r_c] = cos(Phase);
       
        Is0_h[idx_r_c] = sn0[idx_r_c];
        Ic0_h[idx_r_c] = cs0[idx_r_c];
        //WP0[idx_r_c] = atan2(Is0_h[idx_r_c], Ic0_h[idx_r_c]);

        Is_h[idx_r_c] = Is0_h[idx_r_c]; 
        Ic_h[idx_r_c] = Ic0_h[idx_r_c];
//        // calcula el SNR 
//        num += ( (phase+ruido) * (phase+ruido) );
//        den += ( ruido * ruido );
      }

//#ifdef Proc_GPU
  // Copiar memoria del Host al Device
  cudaMemcpy(Is_dev, Is_h, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(Ic_dev, Ic_h, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(WP0_dev, WP0, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(sn0_dev, sn0, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(cs0_dev, cs0, size_matrix_bytes, cudaMemcpyHostToDevice);
  // Copia del device al device
  cudaMemcpy(Is0_dev, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
  cudaMemcpy(Ic0_dev, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
  cudaMemcpy(Is1_dev, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
  cudaMemcpy(Ic1_dev, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);  

  // ************************************************************************
  //             Inicia procesamiento
  // ************************************************************************
//  struct timeval start, end;      // variables de manejo del tiempo
//  gettimeofday( &start, NULL );    // marca tiempo de inicio 
  double start_time, end_time;
  start_time = (double)cv::getTickCount();

  // variables del metodo
  double epsilon1 = EPSILON1;         // criterio de paro del algoritmo, gradiente
  double epsilon2 = EPSILON2;         // criterio de paro del algoritmo, cambio en x
  unsigned ITER1 = ITER_MAX1;      // maximo de iteraciones 
  unsigned iter = 0;             // contador de iteraciones   
  bool flag = true;

  double error, errIs, errIc;
  //long int SizeImage = renglones*columnas;
  
  // inicia iteracion del algoritmo
//  #ifdef Proc_GPU
  // Copiar memoria del Host al Device
  iter = 0;
  double start_timeFun, end_timeFun;
  double sumTimeFun = 0.0;
  double start_timeError, end_timeError;
  double sumTimeError = 0.0;
  start_timeFun = (double)cv::getTickCount();
  double Fx0;

  //Fx0 = Funcional_GPU(Sum_FuncPart, Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, size_Sum_FuncPart, lambda1, lambda2, lambda3, N_threads);
  Fx0 = Funcional_GPU_atomic(Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, sizeof(double), lambda1, lambda2, lambda3, lambda4, lambda5, N_threads);
  
  //cout << "Fx0 : " << Fx0 << endl;

  end_timeFun = (double)cv::getTickCount(); 
  sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency();  
  double sumTime = 0.0;
  double err[2];
  //flag = false;
  while ( flag )
    {
     // resguarda para calculo de error
     // Copia del device al device
     cudaMemcpy(Is0_dev, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
     cudaMemcpy(Ic0_dev, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);

      // calcula iteracion de punto fijo usando Gauss-Seidel
      // retorna solucion actualizada en Is, Ic
      // se promedia tiempo de procesamiento de PF
      double start_timePF, end_timePF;
      start_timePF = (double)cv::getTickCount();
  
      punto_Fijo_TV_GPU(Is_dev, Ic_dev, Is1_dev, Ic1_dev, sn0_dev, cs0_dev, K, renglones, columnas, grid_size_bCond, block_size_FPart, grid_size_FPart, size_matrix_bytes, lambda1, lambda2, lambda3, lambda4, lambda5, BETA); 
      
      end_timePF = (double)cv::getTickCount(); 
      sumTime += (end_timePF - start_timePF) / cv::getTickFrequency();
      
      //P = atan2(Is, Ic);

      start_timeFun = (double)cv::getTickCount();

      //double Fx = Funcional_GPU(Sum_FuncPart, Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, size_Sum_FuncPart, lambda1, lambda2, lambda3, N_threads);
      double Fx = Funcional_GPU_atomic(Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, sizeof(double), lambda1, lambda2, lambda3, lambda4, lambda5, N_threads);

      //double difF = fabs(Fx0-Fx);    
      end_timeFun = (double)cv::getTickCount(); 
      sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency(); 
            
      Fx0 = Fx;
      
      // calcula error de la estimación, despliega avances
      start_timeError = (double)cv::getTickCount();
      //error_relativo_V2_all_GPU(&errIc, &errIs, Sum_pow2difP_pow2P_pow2P0, Sum_pow2difA_pow2A_pow2A0, Sum_pow2difP_pow2P_pow2P0_dev, Sum_pow2difA_pow2A_pow2A0_dev, Ic_dev, Ic0_dev, Is_dev, Is0_dev, renglones, columnas, grid_size_dif, size_Sum_dif_3, smemSize_3, N_threads);
      error_relativo_V2_all_GPU_atomic(&errIc, &errIs, sum_pow2difRRo_dev,sum_pow2Reo_dev,sum_pow2difIIo_dev,sum_pow2Imo_dev, Ic_dev, Ic0_dev, Is_dev, Is0_dev, renglones, columnas, grid_size_dif, size_Sum_dif_3, smemSize_4, N_threads);
    
//      errIs = error_relativo_GPU(Is_dev, Is0_dev, renglones, columnas, grid_size_dif, N_threads);
//      errIc = error_relativo_GPU(Ic_dev, Ic0_dev, renglones, columnas, grid_size_dif, N_threads);
      end_timeError = (double)cv::getTickCount();
      sumTimeError += (end_timeError - start_timeError) / cv::getTickFrequency(); 
      if ( (iter % 50) == 0 )
        {
          cout << "iteracion : " << iter << " Fx= " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;

//          dummy = (atan2( Is, Ic ) + M_PI) / (2.0*M_PI);
//          imshow( win1, Imagen );        waitKey( 1 );
        }
        
      // criterios de paro || (difF < epsilon1)
      if ( (iter >= ITER1)  || (errIs < epsilon1) || (errIc < epsilon2))
        {
          cout << "iteracion : " << iter << " Fx = " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;
          flag = false;
        }

      // incrementa contador iteracion
      iter++;
    }
//#endif
  // termina funcion, calcula y despliega valores indicadores del proceso  
//  gettimeofday( &end, NULL );    // marca de fin de tiempo cronometrado  
  end_time = (double)cv::getTickCount(); 

  // ************************************************************************
  //   resultados del procesamiento
  // ************************************************************************

  // calcula tiempo utilizado milisegundos
//  double startms = double(start.tv_sec)*1000. + double(start.tv_usec)/1000.;
//  double endms = double(end.tv_sec)*1000. + double(end.tv_usec)/1000.;
//  double ms = endms - startms;
//    cout << endl << "Tiempo empleado  : " << ms << " mili-segundos" << endl; 
  cout << endl << "Tiempo total : " << (end_time - start_time) / cv::getTickFrequency() << endl;
  cout << endl << "Tiempo promedio PF : " << sumTime/iter << endl;
  cout << endl << "Tiempo promedio funcional  : " << sumTimeFun / (iter+1) << endl; 
  cout << endl << "Tiempo promedio error  : " << sumTimeError / iter << endl; 
//  cout << endl << "Num threads  : " << N_threads << endl; 
  
//#ifdef Proc_GPU
  // Copiar memoria del Device al Host
  cudaMemcpy(Is_h, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Ic_h, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Is0_h, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Ic0_h, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Is1_h, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Ic1_h, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
//#endif



  cudaFree(Is_dev);
  cudaFree(Ic_dev);
  cudaFree(Is0_dev);
  cudaFree(Ic0_dev);  
  cudaFree(Is1_dev);
  cudaFree(Ic1_dev);  
  cudaFree(WP0_dev); 
  cudaFree(sn0_dev); 
  cudaFree(cs0_dev); 
 
  free(Is_h);
  free(Ic_h);
  free(Is0_h);
  free(Ic0_h);
  free(Is1_h);
  free(Ic1_h);
  free(WP0);
  free(sn0);
  free(cs0);

//  //host memory
//  free(Sum_FuncPart);
//  free(Sum_pow2difP_pow2P_pow2P0);
//  free(Sum_pow2difA_pow2A_pow2A0);
//  free(Sum_pow2difB_pow2B_pow2B0);
//  //Device memory
//  cudaFree(Sum_FuncPart_dev);
//  cudaFree(Sum_pow2difP_pow2P_pow2P0_dev);
//  cudaFree(Sum_pow2difA_pow2A_pow2A0_dev);
//  cudaFree(Sum_pow2difB_pow2B_pow2B0_dev);


  // termina ejecucion del programa
  return 0;
}


////*************************************************************************
////
////    Funciones de trabajo
////
////*************************************************************************
////*************************************************************************
////      genera valor de la fase para una posicion
////*************************************************************************
//double funcionPhase( double x, double y )
//{
//  // declara variables de computo
//  int tipo = TIPO;
//  double phase;
//  
//  // selecciona termino de fase a utilizar
//  switch ( tipo )
//    {
//      case 0:      // fase simple
//        phase = 0.25*M_PI*( x*x + y*y ) / 0.2;
//        break;
//      case 1:      // fase tomada de la funcion peaks de Matlab
//        phase = 5.0*( 3.0*(1.0-x)*(1.0-x)*exp(-x*x - (y+1.0)*(y+1.0)) - 10.0*((x/5.0) - x*x*x - y*y*y*y*y)
//                  * exp(-x*x-y*y) - (1.0/3.0)*exp(-(x+1.0)*(x+1.0) - y*y) );
//        break;
//      case 2:      // fase tomada de la  ec. (24), AppOpt 51, p. 1257
////          x += 0.2;      y += 0.2;
//          phase = 0.5*( 2.6 - 3.9*x 
//                    - 2.6*( 1.0 - 6.0*y*y - 6.0*x*x + 6.0*y*y*y*y + 12.0*x*x*y*y + 6.0*x*x*x*x )
//                    + 6.93*(5.0*x*y*y*y*y - 10.0*x*x*x*y*y + x*x*x*x*x )
//                    + 0.86*(3.0*x - 12.0*x*y*y -12.0*x*x*x + 10.0*x*y*y*y*y + 20.0*x*x*x*y*y + 10.0*x*x*x*x*x )
//                    + 5.2*(-4.0*y*y*y + 12.0*x*x*y + 5.0*y*y*y*y*y - 10.0*x*x*y*y*y - 15.0*x*x*x*x*y ) );
//        break;
//      case 3:      // fase tomada de la ec. (31), JOSA A 16, p. 475
//        phase = 5.0 - 5.0*( 1.0 - 6.0*y*y - 6.0*x*x + 6.0*y*y*y*y + 12.0*x*x*y*y + 6.0*x*x*x*x )
//                  + ( 3.0*x - 12.0*x*y*y - 12.0*x*x*x + 10.0*x*y*y*y*y + 20.0*x*x*x*y*y + 10.0*x*x*x*x*x );
//        break;
//      case 4:      // fase tomada de la ec. (9), OptLett 22, p. 1669
//        phase = 3.0 - 4.5*x - 3.0*( 1.0 - 6.0*y*y - 6.0*x*x + 6.0*y*y*y*y + 12.0*x*x*y*y + 6.0*x*x*x*x )
//                  + 8.0*(5.0*x*y*y*y*y - 10.0*x*x*x*y*y + x*x*x*x*x )
//                  + (3.0*x - 12.0*x*y*y -12.0*x*x*x + 10.0*x*y*y*y*y + 20.0*x*x*x*y*y + 10.0*x*x*x*x*x )
//                  + 6.0*(-4.0*y*y*y + 12.0*x*x*y + 5.0*y*y*y*y*y - 10.0*x*x*y*y*y - 15.0*x*x*x*x*y ); 
//        break;
//      case 5:      // fase tomada de la  ec. (30), AppOpt 49, p. 6224
//          x *= 2.0;       y*= 2.0;
//        phase = 2.0*x*y + 4.0*(2.0*(x*x + y*y) - 1.0) + 2.0*(3.0*(x*x + y*y)*y - 2.0*y);
//        break;
//      case 6:      // fase tomada de la ec. (13),  Proc. SPIE articulo 849319
//        x -= 0.5;      
//        phase = 45.0*( 2.0*x*y + 8.0*(x*x+y*y) + 6.0*(x*x*x*x+y*y*y*y)*y - 4.0*(y+1) );
//        break;
//      case 7:      // fase tomada de la ec. (12),  Proc. SPIE articulo 849319
//        x -= 0.1;      y -= 0.05;
//        phase = 5.0*( 30.0*(x*x + y*y - x*x*x*x - y*y*y*y) - 60.0*x*x*y*y + 3.0*x - 12.0*(x*y*y + x*x*x) 
//                 + 10.0*x*y*y*y*y + 20*x*x*x*y*y + 10*x*x*x*x*x );
//        break;
//      case 8:      // fase tomada de la ec. (11),  Proc. SPIE articulo 849319
//        x += 0.2;      y += 0.2;
//        phase = 13.75*( -1.5*x + 18.0*(x*x + y*y) - 12.0*y*y*y*y - 36.0*x*x*y*y - 18.0*x*x*x*x
//                 + 50.0*x*y*y*y*y - 60.0*x*x*x*y*y + 8.0*x*x*x*x*x -12.0*(x*y*y + x*x*x)
//                 + 10.0*x*x*x*x*x - 24.0*y*y*y + 72.0*x*x*y + 30.0*y*y*y*y*y - 60.0*x*x*y*y*y
//                 + 90.0*x*x*x*x*y );
//        break;

//      case 9:      // plano
//        phase = 4.0*M_PI*x;
//        if ( y < 0.0 )    phase = -1.0*phase - 0.0;
//        break;

//      case 10:      // plano
//        phase = 2.0*M_PI*x;
//        break;

//      case 11:      // fase tomada de 
//        phase = 2.0*2.0*M_PI*( x*x + y*y ) / 0.2;
//        if ( x < 0.0 )    phase *= -1.0;
//        break;
//    }

//  // regresa fase
//  return phase; 
//}


//// ************************************************************************
////       funcion para punto fijo para double
////*************************************************************************
//void punto_Fijo_TV( double* Is_h, double* Ic_h, double* Is1_h, double* Ic1_h )
//{
//  // tamano de arreglo
//  long int SizeImage = renglones*columnas;

//  //condiciones de frontera Neumann para Is, Ic
//  boundaryCond1( Ic_h, Is_h, renglones, columnas );

//  #pragma omp parallel for firstprivate(SizeImage) num_threads(N_T)
//  for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
//     {
//      Is1_h[idx_r_c] = Is_h[idx_r_c];
//      Ic1_h[idx_r_c] = Ic_h[idx_r_c];
//     }
//  // calculo de punto fijo K iteraciones de GS
//  for ( int k = 0; k < K; k++ )
//  {
//   eval_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 0);
//   eval_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 1);
//   
//   eval_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 0);
//   eval_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 1);
//                          
////   // actualiza estimacion
////   #pragma omp parallel for firstprivate(SizeImage) num_threads(N_T)
////   for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
////     {
////      Is_h[idx_r_c] = Is1_h[idx_r_c];
////      Ic_h[idx_r_c] = Ic1_h[idx_r_c];
////     }
//  } //fin de K iteraciones

//}
//// ***************************************************************
////   Gauss-Seidel Red & Black para double
//// ***************************************************************
//void eval_Gauss_Seidel_RB(double* Ic_h, double* Is_h, double* Ic1_h, double* Is1_h, int R_B)
//{
//  double auxIm, auxReal, numIm, denIm, numReal, denReal;
//  double V1x, V2x, V1y, V2y, Ux, Uy;
//  double AIs, BIs, DIs;
//  double AIc, BIc, DIc;
//  long int SizeImage = renglones*columnas;
//  // Paralelizacion de iteracion de Gauss-Seidel-RB
//  // Declaracion de variables para region paralela
//  // private :
//  // firstprivate :  renglones, columnas, R_B, beta, lambda1, lambda2, lambda3
//  #pragma omp parallel for private(auxIm, auxReal, numIm, denIm, numReal, denReal, V1x, V2x, V1y, V2y, Ux, Uy, AIs, BIs, DIs, AIc, BIc, DIc) firstprivate(renglones, columnas, R_B, BETA, lambda1, lambda2, lambda3) num_threads(N_T)
//  for ( int r = 1; r < renglones-1; r++ )
//    for ( int c = 1; c < columnas-1; c++ )
//      {
//        // iteracion de Gauss-Seidel-RB
//        //Red & Black (0,1)
//        if ((r + c) % 2 == R_B) 
//        {  
//         long int idx_r_c = r*columnas + c;
//	 long int idx_rp1_c = (r + 1)*columnas + c;
//	 long int idx_rm1_c = (r - 1)*columnas + c;
//	 long int idx_r_cp1 = r*columnas + c + 1;
//	 long int idx_r_cm1 = r*columnas + c - 1; 
//	 long int idx_rm1_cp1 = (r - 1)*columnas + c + 1; 
//	 long int idx_rp1_cm1 = (r + 1)*columnas + c - 1;      
//        // procesa condiciones de frontera, eje x
////        if ( r == renglones-1 )
////          { AIs = 0.0; AIc = 0.0; }
////        else
////          {  
//            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
//            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
//            AIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
//            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
//            AIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
////          }  
////        if ( r == 0 )
////          { BIs = 0.0; BIc = 0.0; }
////        else
////          {         
//            Ux = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c) - Is(r-1,c);
//            Uy = Is_h[idx_rm1_cp1]-Is_h[idx_rm1_c];//Is(r-1,c+1) - Is(r-1,c);
//            BIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//            Ux = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c) - Ic(r-1,c);
//            Uy = Ic_h[idx_rm1_cp1]-Ic_h[idx_rm1_c];//Ic(r-1,c+1) - Ic(r-1,c);
//            BIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
////          }  
////      
////        // procesa condiciones de frontera, eje y
////        if ( c == columnas-1 )
////          { CIs = 0.0; CIc = 0.0; }
////        else
////          {          
////            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
////            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
////            CIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
////            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
////            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
////            CIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
////          }  
////        if ( c == 0 )
////          {  DIs = 0.0; DIc = 0.0;} 
////        else
////          {	     
//            Ux = Is_h[idx_rp1_cm1]-Is_h[idx_r_cm1];//Is(r+1,c-1) - Is(r,c-1);
//            Uy = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c) - Is(r,c-1);
//            DIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//            Ux = Ic_h[idx_rp1_cm1]-Ic_h[idx_r_cm1];//Ic(r+1,c-1) - Ic(r,c-1);
//            Uy = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c) - Ic(r,c-1);
//            DIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
////          }
//        
//        numReal = lambda1*cs0[idx_r_c] + 2.0*lambda3*Ic_h[idx_r_c] + AIc*Ic_h[idx_rp1_c] + BIc*Ic1_h[idx_rm1_c] + AIc*Ic_h[idx_r_cp1] + DIc*Ic1_h[idx_r_cm1];
//        numIm = lambda2*sn0[idx_r_c] + 2.0*lambda3*Is_h[idx_r_c] + AIs*Is_h[idx_rp1_c] + BIs*Is1_h[idx_rm1_c] + AIs*Is_h[idx_r_cp1] + DIs*Is1_h[idx_r_cm1];

//        auxReal = 2.0*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] ) + lambda1;
//        auxIm = 2.0*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] ) + lambda2;
//        
//        denIm = auxIm + (2.0*AIs + BIs + DIs);
//        denReal = auxReal + (2.0*AIc + BIc + DIc);
//        Is1_h[idx_r_c] = numIm / denIm;
//        Ic1_h[idx_r_c] = numReal / denReal;
//        } // fin de if de Red & Black
//    } // fin ciclos for
//}        


//// ***************************************************************
////   min-mod
//// ***************************************************************
//double minMod( double a, double b )
//{
//  // minmod operator
//  double signa = (a > 0.0) ? 1.0 : ((a < 0.0) ? -1.0 : 0.0);
//  double signb = (b > 0.0) ? 1.0 : ((b < 0.0) ? -1.0 : 0.0);
////  double minim = fmin( fabs(a), fabs(b) ); 
//  double minim = ( fabs(a) <= fabs(b) ) ? fabs(a) : fabs(b); 
//  return ( (signa+signb)*minim/2.0 );

//  // geometric average
////  return( 0.5*(a+b) ); Total Variation Diminishing Runge-Kutta Schemes
//  
//  // upwind 
////  double maxa = (a > 0.0) ? a : 0.0;
////  double maxb = (b > 0.0) ? b : 0.0;
////  return( 0.5*(maxa+maxb) );  
//}
//// ************************************************************************
////       funcional para double
////*************************************************************************
//double Funcional( double* Is_h, double* Ic_h )
//{
//  // define parametro de regularizacion
//  double val = 0.0, v0, v1, v2, v3, a1, a2, a3;
//  double dxIs, dyIs, dxIc, dyIc;
//  double hx = 1.0 / (double(renglones)-1.0);
//  double hy = 1.0 / (double(columnas)-1.0);

//  // evalua derivadas parciales para funcional
//  #pragma omp parallel for reduction(+: val) private(v0, v1, v2, v3, a1, a2, a3, dxIs, dyIs, dxIc, dyIc) firstprivate(renglones, columnas, lambda1, lambda2, lambda3) num_threads(N_T)
//  for ( int r = 0; r < renglones; r++ )
//    for ( int c = 0; c < columnas; c++ )
//      {
//        // campo de gradiente de la informacion
//        if ( c == 0 )
//          {  
//            long int idx_r_c = r*columnas + c;
//            long int idx_r_cp1 = r*columnas + c + 1;
//            dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
//            dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c); 
//           }
//        else if ( c == columnas-1 )
//          {  
//           long int idx_r_c = r*columnas + c;
//           long int idx_r_cm1 = r*columnas + c - 1; 
//           dyIs = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c)-Is(r,c-1);
//           dyIc = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c)-Ic(r,c-1); 
//          }
//        else
//          {  
//           long int idx_r_c = r*columnas + c;
//     	   long int idx_r_cp1 = r*columnas + c + 1;      
//           dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);//0.5*(Is(r,c+1)-Is(r,c-1)); 
//           dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);//0.5*(Ic(r,c+1)-Ic(r,c-1)); }
//          }
//        // campo de gradiente de la informacion
//        if ( r == 0 )
//          {  
//           long int idx_r_c = r*columnas + c;
//	   long int idx_rp1_c = (r + 1)*columnas + c;
//           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c)-Is(r,c);
//           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c)-Ic(r,c); 
//          }
//        else if ( r == renglones-1 )
//          {  
//           long int idx_r_c = r*columnas + c;
//           long int idx_rm1_c = (r - 1)*columnas + c;
//           dxIs = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c)-Is(r-1,c);
//           dxIc = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c)-Ic(r-1,c);
//          }
//        else
//          {  
//           long int idx_r_c = r*columnas + c;
//           long int idx_rp1_c = (r + 1)*columnas + c;
//           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c)-Is(r,c);//0.5*(Is(r+1,c)-Is(r-1,c)); 
//           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c)-Ic(r,c);//0.5*(Ic(r+1,c)-Ic(r-1,c)); 
//          }
//       // termina calculo de derivadas parciales de fase
//       long int idx_r_c = r*columnas + c;
//       a1 = Is_h[idx_r_c]-sn0[idx_r_c];
//       a2 = Ic_h[idx_r_c]-cs0[idx_r_c];
//       a3 = Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] - 1.0;
//       v0 = 0.5 * lambda1 * a1*a1 + 0.5 * lambda2 * a2*a2;
//       v1 = 0.5 * lambda3 * a3 * a3;
//       v2 = sqrt(dxIs*dxIs + dyIs*dyIs);
//       v3 = sqrt(dxIc*dxIc + dyIc*dyIc);
//       val += v0 + v1 + v2 + v3;
//      }

//  // regresa valor
//  return val * hx * hy;
//}

////*************************************************************************
////      obtiene las diferencias envueltas del termino de fase
////*************************************************************************
//double gradientWrap( double p1, double p2 )
//{
//  double r = p1 - p2;
//  return atan2( sin(r), cos(r) ); 
//}
//// ***************************************************************
////   Condiciones de frontera Neumann para double*
//// ***************************************************************
//void boundaryCond1( double* T, int renglones, int columnas )
//{
//	// condiciones de frontera
//	//T(0, all) = T(1, all);
//	//T(renglones - 1, all) = T(renglones - 2, all);
////#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
//	for (int c = 0; c < columnas; c++){
//		long int idx_0_c = c;
//		long int idx_1_c = columnas + c;
//		long int idx_rm1_c = (renglones - 1)*columnas + c;
//		long int idx_rm2_c = (renglones - 2)*columnas + c;

//		T[idx_0_c] = T[idx_1_c];
//		T[idx_rm1_c] = T[idx_rm2_c];
//	}
//	//T(all, 0) = T(all, 1);
//	//T(all, columnas - 1) = T(all, columnas - 2);
////#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
//	for (int r = 0; r < renglones; r++){
//		long int idx_r_0 = r*columnas;
//		long int idx_r_1 = r*columnas + 1;
//		long int idx_r_cm1 = r*columnas + columnas - 1;
//		long int idx_r_cm2 = r*columnas + columnas - 2;

//		T[idx_r_0] = T[idx_r_1];
//		T[idx_r_cm1] = T[idx_r_cm2];
//	}

//	//T(0, 0) = T(1, 1);
//	T[0] = T[columnas + 1];
//	//T(0, columnas - 1) = T(1, columnas - 2);
//	T[columnas - 1] = T[columnas + columnas - 2];
//	//T(renglones - 1, 0) = T(renglones - 2, 1);
//	T[(renglones - 1)*columnas] = T[(renglones - 2)*columnas + 1];
//	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
//	T[(renglones - 1)*columnas + columnas - 1] = T[(renglones - 2)*columnas + columnas - 2];
//}
//// ***************************************************************
////   Condiciones de frontera Neumann para double*, double*
//// ***************************************************************
//void boundaryCond1( double* T1, double* T2, int renglones, int columnas )
//{
//	// condiciones de frontera
//	//T(0, all) = T(1, all);
//	//T(renglones - 1, all) = T(renglones - 2, all);
//        #pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_T)
//	for (int c = 0; c < columnas; c++){
//		long int idx_0_c = c;
//		long int idx_1_c = columnas + c;
//		long int idx_rm1_c = (renglones - 1)*columnas + c;
//		long int idx_rm2_c = (renglones - 2)*columnas + c;

//		T1[idx_0_c] = T1[idx_1_c];
//		T1[idx_rm1_c] = T1[idx_rm2_c];
//		T2[idx_0_c] = T2[idx_1_c];
//		T2[idx_rm1_c] = T2[idx_rm2_c];
//	}
//	//T(all, 0) = T(all, 1);
//	//T(all, columnas - 1) = T(all, columnas - 2);
//        #pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_T)
//	for (int r = 0; r < renglones; r++){
//		long int idx_r_0 = r*columnas;
//		long int idx_r_1 = r*columnas + 1;
//		long int idx_r_cm1 = r*columnas + columnas - 1;
//		long int idx_r_cm2 = r*columnas + columnas - 2;

//		T1[idx_r_0] = T1[idx_r_1];
//		T1[idx_r_cm1] = T1[idx_r_cm2];
//		T2[idx_r_0] = T2[idx_r_1];
//		T2[idx_r_cm1] = T2[idx_r_cm2];
//	}

//	//T(0, 0) = T(1, 1);
//	T1[0] = T1[columnas + 1];
//	//T(0, columnas - 1) = T(1, columnas - 2);
//	T1[columnas - 1] = T1[columnas + columnas - 2];
//	//T(renglones - 1, 0) = T(renglones - 2, 1);
//	T1[(renglones - 1)*columnas] = T1[(renglones - 2)*columnas + 1];
//	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
//	T1[(renglones - 1)*columnas + columnas - 1] = T1[(renglones - 2)*columnas + columnas - 2];
//	
//	T2[0] = T2[columnas + 1];
//	T2[columnas - 1] = T2[columnas + columnas - 2];
//	T2[(renglones - 1)*columnas] = T2[(renglones - 2)*columnas + 1];
//	T2[(renglones - 1)*columnas + columnas - 1] = T2[(renglones - 2)*columnas + columnas - 2];	
//	
//}
////***************************************************
//// Error relativo para parte real y parte imaginaria
//// P = nueva estimacion
//// Po = estimacion anterior
////***************************************************
//void error_relativo(double* errorRe, double* errorIm, double* Re, double* Reo, double* Im, double* Imo)
//{
//double sum_pow2difRRo = 0.0, sum_pow2Reo = 0.0, sum_pow2difIIo = 0.0, sum_pow2Imo = 0.0;
//long int SizeImage = renglones * columnas;

//#pragma omp parallel for reduction(+:sum_pow2difRRo,sum_pow2Reo, sum_pow2difIIo, sum_pow2Imo) firstprivate(SizeImage) num_threads(N_T)
//for (int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
//  {
//   double vRe = Re[idx_r_c];
//   double vReo = Reo[idx_r_c];
//   double difRe = vRe-vReo;
//   sum_pow2difRRo += difRe*difRe;
//   sum_pow2Reo += vReo*vReo;  
//   double vIm = Im[idx_r_c];
//   double vImo = Imo[idx_r_c];
//   double difIm = vIm-vImo;
//   sum_pow2difIIo += difIm*difIm;
//   sum_pow2Imo += vImo*vImo;     
//  }

//*errorRe = sqrt(sum_pow2difRRo) / sqrt(sum_pow2Reo);
//*errorIm = sqrt(sum_pow2difIIo) / sqrt(sum_pow2Imo);
//}

