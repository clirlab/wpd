//*************************************************************************
////     * CODIGO SECUENCIAL FLOAT *
//    Programa que resuelve el modelo para filtrado utilizando punto fijo
//    realiza K iteraciones de Gauss-Seidel con Red & Black
//    Funciones implementadas para arreglos de tipo float*
//    
//
// Author       : Iván de Jesús May-Cen
// Language     : C++
// Compiler     : g++
// Environment  : 
// Revisions
//   Initial    : 2023-05-04 17:36:44 
//   Last       : 
// 
//
//  para compilar
//    g++ -O2 -fopenmp filtradoANMNmulticore.cpp -o test_mul -lrt -lblitz -lgomp `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//  para ejecutar
//
//    ./test_mul image.png Num_threads
//    ./test_mul wp480x640-ANMN-02.png 2
// 
//*************************************************************************

// preprocesor directives
#include <opencv2/core/core.hpp>                // OpenCV      
#include <opencv2/highgui/highgui.hpp>           
//#include <blitz/array.h>                                // Blitz++             
//#include <random/uniform.h>
//#include <random/normal.h>
#include <sys/time.h>                   // funciones de tiempo
#include <cmath>                        // funciones matematicas
#include <float.h>                      // mathematical constants
#include <iostream>                                  
#include <fstream> 

// declara namespace
using namespace std;
using namespace cv;
//using namespace blitz;
//using namespace ranlib;
// REFERENCIAS
/*
[1] Chumchob, N., Chen, K., & Brito-Loeza, C. (2013). A new variational model for removal of combined additive and multiplicative noise and a fast algorithm for its numerical approximation. International Journal of Computer Mathematics, 90(1), 140-161.

[2] Hirakawa, K., & Parks, T. W. (2006). Image denoising using total least squares. IEEE Transactions on image processing, 15(9), 2730-2742.
*/

  int renglones, columnas, N_T;
  float *sn0, *cs0; //Variable global para fase ruidosa
  char imgname[50];

// parametros para funcional a utilizar en la optimizacion
const float LAMBDA1 = 1.0f;    //para termino de ajuste parte real
const float LAMBDA2 = 1.0f;    //para termino de ajuste parte imaginaria
const float LAMBDA3 = 1.0f;//5 //para condicion apriori
const float LAMBDA4 = 0.1f;    //para termino con exponencial parte real
const float LAMBDA5 = 0.1f;    //para termino con exponencial parte imaginaria
const float LAMBDA = 1.0f;     //para regularizadores
const int TIPO = 9, K = 3;
const float BETA = 1.0e-3f;


// variables del metodo numerico
const float EPSILON1 = 1.0e-6f;         // criterio de paro del algoritmo, gradiente
const float EPSILON2 = 1.0e-6f;         // criterio de paro del algoritmo, cambio en x
const unsigned ITER_MAX1 = 200000;    // maximo de iteraciones 

// declaracion de funciones
float gradientWrap(float, float);
float minMod(float, float);  

// Funciones float para calculos numericos
void error_relativo(float* errorRe, float* errorIm, float* Re, float* Reo, float* Im, float* Imo);
float Funcional( float* Is_h, float* Ic_h );
void iteracion_Gauss_Seidel_RB( float* Is_h, float* Ic_h, float*  Is1_h, float* Ic1_h, int R_B);
void punto_Fijo_TV_ANMN( float* Is_h, float* Ic_h, float* Is1_h, float* Ic1_h );
void boundaryCond1( float* T1, float* T2, int renglones, int columnas );

//*************************************************************************
//
//                        inicia funcion principal
//
//*************************************************************************
int main( int argc, char **argv )
{
  //parametros desde consola
  if(argc == 3) 
    {
     //version para lectura de imagen
     // read name of the file, read image
     // read name of the file, read image
     strcpy( imgname, argv[1] );
     N_T = atoi(argv[2]);
    }

  // despliega informacion del proceso
  cout << endl << "Inicia procesamiento..." << endl << endl;
  cout << endl << "Lee datos ruidosos..." << endl << endl;  

  // Leemos datos de la imagen
  Mat IMAGEN = imread(imgname, IMREAD_GRAYSCALE);
  if( !IMAGEN.data )
    {
      cout << "Error en la lectura de la imagen inicial..." << endl;
      return -1;
    }
  renglones = IMAGEN.rows, columnas = IMAGEN.cols;

  
  int tonos = 256; // tonos de gris
  float omega = 2.0f * M_PI / float(tonos);
  float LUT[tonos];
  for ( int x = 0; x < tonos; x++ )
    {
      float fase = omega*float(x+1) - M_PI;
      LUT[x] = atan2f( sinf(fase), cosf(fase) );
    }  
  
  // Arreglos para calculos numericos
  float *Is_h, *Ic_h, *Is0_h, *Ic0_h, *Is1_h, *Ic1_h;
  long int size_matrix = renglones*columnas;
  size_t size_matrix_bytes = size_matrix * sizeof(float);
  Is_h = (float*)malloc(size_matrix_bytes);
  Ic_h = (float*)malloc(size_matrix_bytes);
  Is0_h = (float*)malloc(size_matrix_bytes);
  Ic0_h = (float*)malloc(size_matrix_bytes);  
  Is1_h = (float*)malloc(size_matrix_bytes);
  Ic1_h = (float*)malloc(size_matrix_bytes);  
  sn0 = (float*)malloc(size_matrix_bytes);   
  cs0 = (float*)malloc(size_matrix_bytes); 

  // genera patrones de franjas
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // Lee valores desde imagen
        float Phase = LUT[IMAGEN.at<unsigned char>(r,c)];
        long int idx_r_c = r*columnas + c;
       
        // arreglos con datos de sin y cos de fase ruidosa      
        sn0[idx_r_c] = sinf(Phase);
        cs0[idx_r_c] = cosf(Phase);
       
        Is0_h[idx_r_c] = sn0[idx_r_c];
        Ic0_h[idx_r_c] = cs0[idx_r_c];
        //WP0[idx_r_c] = atan2(Is0_h[idx_r_c], Ic0_h[idx_r_c]);

        Is_h[idx_r_c] = Is0_h[idx_r_c]; 
        Ic_h[idx_r_c] = Ic0_h[idx_r_c];
      }




  // ************************************************************************
  //             Inicia procesamiento
  // ************************************************************************
  float start_time, end_time;
  start_time = (float)cv::getTickCount();

  // variables del metodo
  float epsilon1 = EPSILON1;         // criterio de paro del algoritmo, gradiente
  float epsilon2 = EPSILON2;         // criterio de paro del algoritmo, cambio en x
  float errIs, errIc;
  unsigned ITER1 = ITER_MAX1;      // maximo de iteraciones 
  unsigned iter = 0;             // contador de iteraciones   
  bool flag = true;
  long int SizeImage = renglones*columnas;

  //const char *win1 = "Estimaciones";        namedWindow( win1, WINDOW_AUTOSIZE );

  float Fx0 = Funcional( Is_h, Ic_h );

  while ( flag )
    {
      // resguarda para calculo de error
     #pragma omp parallel for firstprivate(SizeImage) num_threads(N_T)
     for(long int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
       {
        // resguarda para calculo de error
        Is0_h[idx_r_c] = Is_h[idx_r_c];
        Ic0_h[idx_r_c] = Ic_h[idx_r_c];
       }
      // calcula iteracion de Gauss-Seidel
      // retorna solucion actualizada en Is, Ic
      punto_Fijo_TV_ANMN(Is_h, Ic_h, Is1_h, Ic1_h);

      //P = atan2(Is, Ic);

      float Fx = Funcional( Is_h, Ic_h );
      float difF = fabs(Fx0-Fx);    

      Fx0 = Fx;
      
      // calcula error de la estimación, despliega avances
      error_relativo(&errIc, &errIs, Ic_h, Ic0_h, Is_h, Is0_h);
      if ( (iter % 50) == 0 )
        {
          cout << "iteracion : " << iter << " Fx= " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;

//        for(int r = 0; r < renglones; r++) 
//          for(int c = 0; c < columnas; c++) 
//            {
//             long int idx_r_c = r*columnas + c;
//             dummy(r,c) = (atan2( Is_h[idx_r_c], Ic_h[idx_r_c] ) + M_PI) / (2.0*M_PI);      
//            }
          //dummy = (atan2( Is, Ic ) + M_PI) / (2.0*M_PI);
          //imshow( win1, Imagen );        waitKey( 1 );
        }
        
      // criterios de paro || (difF < epsilon1)
      if ( (iter >= ITER1)  || (errIs < epsilon1) || (errIc < epsilon2))
        {
          cout << "iteracion : " << iter << " Fx = " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;
          flag = false;
        }

      // incrementa contador iteracion
      iter++;
    }

  // termina funcion, calcula y despliega valores indicadores del proceso  
  end_time = (float)cv::getTickCount(); 
  cout << endl << "Tiempo empleado : " << (end_time - start_time) / cv::getTickFrequency() << endl; 

  
  // termina ejecucion del programa



  free(Is_h);
  free(Ic_h);
  free(Is0_h);
  free(Ic0_h);
  free(Is1_h);
  free(Ic1_h);
  free(sn0);
  free(cs0);
  // termina ejecucion del programa
  return 0;
}


//*************************************************************************
//
//    Funciones de trabajo
//
//*************************************************************************
// ************************************************************************
//       funcion para Gauss-Seidel para float
//*************************************************************************
void punto_Fijo_TV_ANMN( float* Is_h, float* Ic_h, float* Is1_h, float* Ic1_h )
{
  long int SizeImage = renglones*columnas;
  
  //condiciones de frontera Neumann para Is, Ic
  boundaryCond1( Ic_h, Is_h, renglones, columnas );
  
  #pragma omp pararell for firstprivate(SizeImage) num_threads(N_T)
  for(long int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
     {
      Is1_h[idx_r_c] = Is_h[idx_r_c];
      Ic1_h[idx_r_c] = Ic_h[idx_r_c];
     }
  // calculo de punto fijo K iteraciones de GS
  for ( int k = 0; k < K; k++ )
  {
   iteracion_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 0);
   iteracion_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 1);
   
   iteracion_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 0);
   iteracion_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 1);

// Actualiza informacion
//#pragma omp pararell for firstprivate(SizeImage) num_threads(N_T)
//     for(long int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++)
//       {
//        Is_h[idx_r_c] = Is1_h[idx_r_c];
//        Ic_h[idx_r_c] = Ic1_h[idx_r_c];
//       }
    }
  
}
void iteracion_Gauss_Seidel_RB(float* Ic_h, float* Is_h, float* Ic1_h, float* Is1_h, int R_B)
{
  // define parametro de regularizacion
  float lambda1 = LAMBDA1, lambda2 = LAMBDA2, lambda3 = LAMBDA3, lambda4 = LAMBDA4, lambda5 = LAMBDA5, lambda = LAMBDA;
  float beta = BETA;
  float V1x, V2x, V1y, V2y, Ux, Uy;
  float AIs, BIs, DIs, numIs, denIs;
  float AIc, BIc, DIc, numIc, denIc;
  float residuo, aux;
  
  // Paralelizacion de iteracion de Gauss-Seidel-RB
  // Declaracion de variables para region paralela
  // private :
  // firstprivate :  renglones, columnas, R_B, beta, lambda1, lambda2, lambda3
  #pragma omp parallel for private(aux, numIs, denIs, numIc, denIc, V1x, V2x, V1y, V2y, Ux, Uy, AIs, BIs, DIs, AIc, BIc, DIc) firstprivate(renglones, columnas, R_B, beta, lambda1, lambda2, lambda3, lambda4, lambda5, lambda) num_threads(N_T)
  for ( int r = 1; r < renglones-1; r++ )
    for ( int c = 1; c < columnas-1; c++ )
      {
        // iteracion de Gauss-Seidel-RB
        //Red & Black (0,1)
        if ((r + c) % 2 == R_B) 
        {  
       long int idx_r_c = r*columnas + c;
       long int idx_rp1_c = (r + 1)*columnas + c;
       long int idx_rm1_c = (r - 1)*columnas + c;
       long int idx_r_cp1 = r*columnas + c + 1;
       long int idx_r_cm1 = r*columnas + c - 1; 
       long int idx_rm1_cp1 = (r - 1)*columnas + c + 1; 
       long int idx_rp1_cm1 = (r + 1)*columnas + c - 1; 
//       // procesa condiciones de frontera, eje x
//        if ( r == renglones-1 )
//          { AIs = 0.0; AIc = 0.0; }
//        else
//          {
            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
            AIs = 1.0f / sqrtf( Ux*Ux + Uy*Uy + beta );
            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
            AIc = 1.0f / sqrtf( Ux*Ux + Uy*Uy + beta );
//          }  
//        if ( r == 0 )
//          { BIs = 0.0; BIc = 0.0; }
//        else
//          {         
            Ux = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c) - Is(r-1,c);
            Uy = Is_h[idx_rm1_cp1]-Is_h[idx_rm1_c];//Is(r-1,c+1) - Is(r-1,c);
            BIs = 1.0f / sqrtf( Ux*Ux + Uy*Uy + beta );
            Ux = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c) - Ic(r-1,c);
            Uy = Ic_h[idx_rm1_cp1]-Ic_h[idx_rm1_c];//Ic(r-1,c+1) - Ic(r-1,c);
            BIc = 1.0f / sqrtf( Ux*Ux + Uy*Uy + beta );
//          }  
//      
//        // procesa condiciones de frontera, eje y
//        if ( c == columnas-1 )
//          { CIs = 0.0; CIc = 0.0; }
//        else
//          {  /* AIc = CIc,  AIs = CIs */ 
//            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
//            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
//            CIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + beta );
//            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
//            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
//            CIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + beta );
//          }  
//        if ( c == 0 )
//          {  DIs = 0.0; DIc = 0.0;} 
//        else
//          {
            Ux = Is_h[idx_rp1_cm1]-Is_h[idx_r_cm1];//Is(r+1,c-1) - Is(r,c-1);
            Uy = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c) - Is(r,c-1);
            DIs = 1.0f / sqrtf( Ux*Ux + Uy*Uy + beta );
            Ux = Ic_h[idx_rp1_cm1]-Ic_h[idx_r_cm1];//Ic(r+1,c-1) - Ic(r,c-1);
            Uy = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c) - Ic(r,c-1);
            DIc = 1.0f / sqrtf( Ux*Ux + Uy*Uy + beta );
//          }

        // iteracion de Gauss-Seidel
        numIs = lambda2*sn0[idx_r_c] + 2.0f*lambda3*Is_h[idx_r_c] + lambda*(AIs*Is_h[idx_rp1_c] + BIs*Is1_h[idx_rm1_c] + AIs*Is_h[idx_r_cp1] + DIs*Is1_h[idx_r_cm1]) - lambda5*(1.0f-sn0[idx_r_c]);
        numIc = lambda1*cs0[idx_r_c] + 2.0f*lambda3*Ic_h[idx_r_c] + lambda*(AIc*Ic_h[idx_rp1_c] + BIc*Ic1_h[idx_rm1_c] + AIc*Ic_h[idx_r_cp1] + DIc*Ic1_h[idx_r_cm1]) - lambda4*(1.0f-cs0[idx_r_c]);

        aux = 2.0f*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] );

        denIs = lambda5*sn0[idx_r_c] + lambda2 + aux + lambda*(2.0f*AIs + BIs + DIs);
        denIc = lambda4*cs0[idx_r_c] + lambda1 + aux + lambda*(2.0f*AIc + BIc + DIc);
        Is1_h[idx_r_c] = numIs / denIs;
        Ic1_h[idx_r_c] = numIc / denIc;
        } // fin de if de Red & Black
    } // fin ciclos for

}
// ***************************************************************
//   Condiciones de frontera Neumann para float*, float*
// ***************************************************************
void boundaryCond1( float* T1, float* T2, int renglones, int columnas )
{
	// condiciones de frontera
	//T(0, all) = T(1, all);
	//T(renglones - 1, all) = T(renglones - 2, all);
        #pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_T)
	for (int c = 0; c < columnas; c++){
		long int idx_0_c = c;
		long int idx_1_c = columnas + c;
		long int idx_rm1_c = (renglones - 1)*columnas + c;
		long int idx_rm2_c = (renglones - 2)*columnas + c;

		T1[idx_0_c] = T1[idx_1_c];
		T1[idx_rm1_c] = T1[idx_rm2_c];
		T2[idx_0_c] = T2[idx_1_c];
		T2[idx_rm1_c] = T2[idx_rm2_c];
	}
	//T(all, 0) = T(all, 1);
	//T(all, columnas - 1) = T(all, columnas - 2);
        #pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_T)
	for (int r = 0; r < renglones; r++){
		long int idx_r_0 = r*columnas;
		long int idx_r_1 = r*columnas + 1;
		long int idx_r_cm1 = r*columnas + columnas - 1;
		long int idx_r_cm2 = r*columnas + columnas - 2;

		T1[idx_r_0] = T1[idx_r_1];
		T1[idx_r_cm1] = T1[idx_r_cm2];
		T2[idx_r_0] = T2[idx_r_1];
		T2[idx_r_cm1] = T2[idx_r_cm2];
	}

	//T(0, 0) = T(1, 1);
	T1[0] = T1[columnas + 1];
	//T(0, columnas - 1) = T(1, columnas - 2);
	T1[columnas - 1] = T1[columnas + columnas - 2];
	//T(renglones - 1, 0) = T(renglones - 2, 1);
	T1[(renglones - 1)*columnas] = T1[(renglones - 2)*columnas + 1];
	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
	T1[(renglones - 1)*columnas + columnas - 1] = T1[(renglones - 2)*columnas + columnas - 2];
	
	T2[0] = T2[columnas + 1];
	T2[columnas - 1] = T2[columnas + columnas - 2];
	T2[(renglones - 1)*columnas] = T2[(renglones - 2)*columnas + 1];
	T2[(renglones - 1)*columnas + columnas - 1] = T2[(renglones - 2)*columnas + columnas - 2];	
	
}


// ***************************************************************
//   min-mod
// ***************************************************************
float minMod( float a, float b )
{
  // minmod operator
  float signa = (a > 0.0f) ? 1.0f : ((a < 0.0f) ? -1.0f : 0.0f);
  float signb = (b > 0.0f) ? 1.0f : ((b < 0.0f) ? -1.0f : 0.0f);
//  float minim = fmin( fabs(a), fabs(b) ); 
  float minim = ( fabsf(a) <= fabsf(b) ) ? fabsf(a) : fabsf(b); 
  return ( (signa+signb)*minim/2.0f );

  // geometric average
//  return( 0.5*(a+b) ); Total Variation Diminishing Runge-Kutta Schemes
  
  // upwind 
//  float maxa = (a > 0.0) ? a : 0.0;
//  float maxb = (b > 0.0) ? b : 0.0;
//  return( 0.5*(maxa+maxb) );  
}
// ************************************************************************
//       funcional para float
//*************************************************************************
float Funcional( float* Is_h, float* Ic_h )
{
  // define parametro de regularizacion
  float lambda1 = LAMBDA1, lambda2 = LAMBDA2, lambda3 = LAMBDA3, lambda4 = LAMBDA4, lambda5 = LAMBDA5, lambda = LAMBDA, val = 0.0f, v0, v1, v2, v3, v4, a1, a2, a3;
  float t1, t2;
  float dxIs, dyIs, dxIc, dyIc;
  float hx = 1.0f / (float(renglones)-1.0f);
  float hy = 1.0f / (float(columnas)-1.0f);


  // evalua derivadas parciales para funcional
  // evalua derivadas parciales para funcional
  // Paralelizacion de evaluacion de funcional
  // Declaracion de variables para region paralela
  // private :
  // firstprivate :  renglones, columnas, lambda1, lambda2, lambda3
  #pragma omp parallel for reduction(+: val) private(v0, v1, v2, v3, v4, a1, a2, a3, t1, t2, dxIs, dyIs, dxIc, dyIc) firstprivate(renglones, columnas, lambda1, lambda2, lambda3, lambda4, lambda5, lambda) num_threads(N_T)
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // campo de gradiente de la informacion
        if ( c == 0 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_r_cp1 = r*columnas + c + 1;
           dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
           dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c); 
           }
        else if ( c == columnas-1 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_r_cm1 = r*columnas + c - 1; 
           dyIs = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c)-Is(r,c-1);
           dyIc = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c)-Ic(r,c-1); 
           }
        else
          {  
           long int idx_r_c = r*columnas + c;
     	   long int idx_r_cp1 = r*columnas + c + 1; 
           dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
           dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
          }
          
        // campo de gradiente de la informacion
        if ( r == 0 )
          {  
           long int idx_r_c = r*columnas + c;
	   long int idx_rp1_c = (r + 1)*columnas + c;
           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];
           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];
          }
        else if ( r == renglones-1 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_rm1_c = (r - 1)*columnas + c;
           dxIs = Is_h[idx_r_c]-Is_h[idx_rm1_c];
           dxIc = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];
          }
        else
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_rp1_c = (r + 1)*columnas + c;
           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c]; 
           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];
           }
       // termina calculo de derivadas parciales de fase
       long int idx_r_c = r*columnas + c;
       a1 = Is_h[idx_r_c]-sn0[idx_r_c];
       a2 = Ic_h[idx_r_c]-cs0[idx_r_c];
       a3 = Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] - 1.0f;
       t1 = Is_h[idx_r_c] + sn0[idx_r_c]*(expf(-Is_h[idx_r_c]));
       t2 = Ic_h[idx_r_c] + cs0[idx_r_c]*(expf(-Ic_h[idx_r_c]));
       v0 = 0.5f * lambda3 * a3 * a3;
       v1 = 0.5f*lambda2*a1*a1 + 0.5f*lambda1*a2*a2;
       v2 = lambda*sqrtf(dxIs*dxIs + dyIs*dyIs);
       v3 = lambda*sqrtf(dxIc*dxIc + dyIc*dyIc);
       v4 = lambda5*t1 + lambda4*t2;
       val += v0 + v1 + v2 + v3 + v4;
      }

  // regresa valor
  return val * hx * hy;
}

//*************************************************************************
//      obtiene las diferencias envueltas del termino de fase
//*************************************************************************
float gradientWrap( float p1, float p2 )
{
  float r = p1 - p2;
  return atan2f( sinf(r), cosf(r) ); 
}
//***************************************************
// Error relativo para parte real y parte imaginaria
// P = nueva estimacion
// Po = estimacion anterior
//***************************************************
void error_relativo(float* errorRe, float* errorIm, float* Re, float* Reo, float* Im, float* Imo)
{
float sum_pow2difRRo = 0.0f, sum_pow2Reo = 0.0f, sum_pow2difIIo = 0.0f, sum_pow2Imo = 0.0f;
long int SizeImage = renglones * columnas;

#pragma omp parallel for reduction(+:sum_pow2difRRo,sum_pow2Reo, sum_pow2difIIo, sum_pow2Imo) firstprivate(SizeImage) num_threads(N_T)
for (long int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
  {
   float vRe = Re[idx_r_c];
   float vReo = Reo[idx_r_c];
   float difRe = vRe-vReo;
   sum_pow2difRRo += difRe*difRe;
   sum_pow2Reo += vReo*vReo;  
   float vIm = Im[idx_r_c];
   float vImo = Imo[idx_r_c];
   float difIm = vIm-vImo;
   sum_pow2difIIo += difIm*difIm;
   sum_pow2Imo += vImo*vImo;     
  }

*errorRe = sqrtf(sum_pow2difRRo) / sqrtf(sum_pow2Reo);
*errorIm = sqrtf(sum_pow2difIIo) / sqrtf(sum_pow2Imo);
}

