//*************************************************************************
//    * CODIGO GPU *
//    Programa que resuelve el modelo para filtrado utilizando punto fijo
//    realiza K iteraciones de Gauss-Seidel
//
// Author       : Iván de Jesús May-Cen
// Language     : C++
// Compiler     : g++
// Environment  : 
// Revisions
//   Initial    : 2023-05-09 09:36:44 
//   Last       : 
//
//  para compilar
//    g++ -O2 -fopenmp filtradoANMNGPU.cu -o test_gpu -lrt -lgomp `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//  para ejecutar
//    ./test_gpu
//  Paralelo usando GPU - CUDA:
//    nvcc -arch=compute_75 -Xcompiler `pkg-config --cflags --libs opencv` -I /usr/local/cuda-8.0/include/ -L /usr/local/cuda-8.0/lib64/ -lcuda -lcudart -lopencv_core -lopencv_highgui -lopencv_imgproc filtradoPFTVtest_GPU.cu filtradoPFTVtest.cpp -o test_gpu
//
//       VERSION SIN LA LIBRERIA BLITZ
//         09 / Mayo / 2023
//
//  Paralelo usando GPU - CUDA:
//    nvcc -arch=compute_75 -Xcompiler `pkg-config --cflags --libs opencv` -I /usr/local/cuda-8.0/include/ -L /usr/local/cuda-8.0/lib64/ -lcuda -lcudart -lopencv_core -lopencv_highgui -lopencv_imgproc filtradoPFTVtest_GPU.cu filtradoPFTVtest.cpp -o test_gpu
//
//  para ejecutar:
//    ./test ArchivoImagen.png
//    ./test wp480x640-ANMN-02.png
//
// 
//*************************************************************************

// preprocesor directives
#include <opencv2/core/core.hpp>                // OpenCV      
#include <opencv2/highgui/highgui.hpp>           
#include <sys/time.h>                   // funciones de tiempo
#include <cmath>                        // funciones matematicas
#include <float.h>                      // mathematical constants
#include <iostream>                                  
#include <fstream> 

//defines
#define Proc_GPU

#ifdef Proc_GPU
#include "filtradoPFTVtest_GPU.cuh"
#endif 

// declara namespace
using namespace std;
using namespace cv;


// parametros para funcional a utilizar en la optimizacion
const float lambda1 = 1.0f;
const float lambda2 = 1.0f;
const float lambda3 = 1.0f;
const float lambda4 = 0.1f;
const float lambda5 = 0.1f;
const int TIPO = 9, K = 3; // 5
const float BETA = 1.0e-3f, EPS0 = 0.01f, EPS = sqrtf(DBL_EPSILON);

// variables del metodo numerico
const float EPSILON1 = 1.0e-6f;         // criterio de paro del algoritmo, gradiente
const float EPSILON2 = 1.0e-6f;         // criterio de paro del algoritmo, cambio en x
const unsigned ITER_MAX1 = 200000;    // maximo de iteraciones 


  // datos de la imagen
  int renglones, columnas, N_T, N_threads = 2, ban_proc;
  //Variable global para fase ruidosa
  float* WP0, *sn0, *cs0; 


//*************************************************************************
//
//                        inicia funcion principal
//
//*************************************************************************
int main( int argc, char **argv )
{

  char imgname[50];  //nombre de archivo para franjas con portadora
  //parametros desde consola
  if(argc == 2) 
    {
     // read name of the file, read image
     strcpy( imgname, argv[1] );
    }

  // despliega informacion del proceso
  cout << endl << "Inicia procesamiento..." << endl << endl;
  cout << endl << "Lee datos ruidosos..." << endl << endl;  

  // datos de la imagen
  Mat IMAGEN = imread(imgname, IMREAD_GRAYSCALE);
  if( !IMAGEN.data )
    {
      cout << "Error en la lectura de la imagen inicial..." << endl;
      return -1;
    }
  renglones = IMAGEN.rows, columnas = IMAGEN.cols;

 
  // Arreglos para calculos numericos
  float *Is_h, *Ic_h, *Is0_h, *Ic0_h, *Is1_h, *Ic1_h;
  long int size_matrix = renglones*columnas;
  size_t size_matrix_bytes = size_matrix * sizeof(float);
  Is_h = (float*)malloc(size_matrix_bytes);
  Ic_h = (float*)malloc(size_matrix_bytes);
  Is0_h = (float*)malloc(size_matrix_bytes);
  Ic0_h = (float*)malloc(size_matrix_bytes);  
  Is1_h = (float*)malloc(size_matrix_bytes);
  Ic1_h = (float*)malloc(size_matrix_bytes);  
  WP0 = (float*)malloc(size_matrix_bytes);  
  sn0 = (float*)malloc(size_matrix_bytes);
  cs0 = (float*)malloc(size_matrix_bytes);
 
//#ifdef Proc_GPU
  // memoria para GPU
  float *Is_dev, *Ic_dev, *Is0_dev, *Ic0_dev, *Is1_dev, *Ic1_dev, *WP0_dev, *sn0_dev, *cs0_dev;
  //long int size_matrix = renglones*columnas;
  //size_t size_matrix_bytes = size_matrix * sizeof(float);
  cudaMalloc((void **)&Is_dev, size_matrix_bytes);
  cudaMalloc((void **)&Ic_dev, size_matrix_bytes);
  cudaMalloc((void **)&Is0_dev, size_matrix_bytes);
  cudaMalloc((void **)&Ic0_dev, size_matrix_bytes);
  cudaMalloc((void **)&Is1_dev, size_matrix_bytes);
  cudaMalloc((void **)&Ic1_dev, size_matrix_bytes);
  cudaMalloc((void **)&WP0_dev, size_matrix_bytes);
  cudaMalloc((void **)&sn0_dev, size_matrix_bytes);
  cudaMalloc((void **)&cs0_dev, size_matrix_bytes);
  // Configuración de los tamaños de la malla y el bloque de hilos
  int max_ren_col = max(renglones, columnas);
  int grid_size_bCond = iDivUp(max_ren_col, BLOCKDIM_X);
  dim3 block_size_FPart(BLOCKDIM_X, BLOCKDIM_Y,1);
  dim3 grid_size_FPart(iDivUp(columnas - 2, BLOCKDIM_X), iDivUp(renglones - 2,BLOCKDIM_Y), 1);
  dim3 block_size_evalF(BLOCKDIM_X, BLOCKDIM_Y, 1);
  dim3 grid_size_evalF(iDivUp(columnas, BLOCKDIM_X), iDivUp(renglones, BLOCKDIM_Y), 1);
  long int grid_size_dif= iDivUp(size_matrix, BLOCKDIM_X_1D);

  //para la memoria compartida en cada bloque de hilos
  size_t smemSize_FuncPart = BLOCKDIM_X * BLOCKDIM_Y * sizeof(float);
  size_t smemSize_3        = 9 * BLOCKDIM_X_1D * sizeof(float);  //Hay que tener cuidado de no pasarnos de los 48KB
  size_t smemSize_4 = 4 * BLOCKDIM_X_1D_T * sizeof(float); //El tamaño de los hilos por bloque en este caso puede ser de 1024
	                                                         //Vamos a cambiar el BLOCKDIM_X_1D a 672  
  size_t smemSize_1        = 3 * BLOCKDIM_X_1D_T * sizeof(float);//Aquí no nos pasamos de los 48KB de memoria compartida
#ifdef atomics_GPU                                         
	size_t size_Sum_dif_3 = 3 * sizeof(float);
	size_t size_Sum_FuncPart = sizeof(float);
#else      //sin atomics usamos los cores del CPU para realizar la última parte de la sumatoria
	size_t size_Sum_dif_3 = 3 * grid_size_dif * sizeof(float);
	size_t size_Sum_FuncPart = grid_size_evalF.x * grid_size_evalF.y * sizeof(float);	
#endif

	//host memory
	float* Sum_FuncPart = (float*)malloc(size_Sum_FuncPart);
	float* Sum_pow2difP_pow2P_pow2P0 = (float*)malloc(size_Sum_dif_3);
	float* Sum_pow2difA_pow2A_pow2A0 = (float*)malloc(size_Sum_dif_3);
	float* Sum_pow2difB_pow2B_pow2B0 = (float*)malloc(size_Sum_dif_3);
	//Device memory
	float* Sum_FuncPart_dev;
	//cudaMalloc((void**)&Sum_FuncPart_dev, size_Sum_FuncPart);
    cudaMalloc((void**)&Sum_FuncPart_dev, sizeof(float));
	
    float *sum_pow2difRRo_dev,*sum_pow2Reo_dev,*sum_pow2difIIo_dev,*sum_pow2Imo_dev;

    cudaMalloc((void**)&sum_pow2difRRo_dev, sizeof(float));
    cudaMalloc((void**)&sum_pow2Reo_dev, sizeof(float));
    cudaMalloc((void**)&sum_pow2difIIo_dev, sizeof(float));
    cudaMalloc((void**)&sum_pow2Imo_dev, sizeof(float));
    
    /*float* Sum_pow2difP_pow2P_pow2P0_dev;
    float* Sum_pow2difA_pow2A_pow2A0_dev;
    float* Sum_pow2difB_pow2B_pow2B0_dev;
    cudaMalloc((void**)&Sum_pow2difP_pow2P_pow2P0_dev, size_Sum_dif_3);
	cudaMalloc((void**)&Sum_pow2difA_pow2A_pow2A0_dev, size_Sum_dif_3);
	cudaMalloc((void**)&Sum_pow2difB_pow2B_pow2B0_dev, size_Sum_dif_3);*/
  //#endif
//#endif // Proc_GPU



  
  // crea manejador de imagenes con openCV
//  Mat Imagen( renglones, columnas, CV_64F, (unsigned char*) dummy.data() );
//  const char *win0 = "Fase a recuperar";      namedWindow( win0, WINDOW_AUTOSIZE );
//  const char *win1 = "Estimaciones";          namedWindow( win1, WINDOW_AUTOSIZE );


  int tonos = 256; // tonos de gris
  float omega = 2.0f * M_PI / float(tonos);
  float LUT[tonos];
  for ( int x = 0; x < tonos; x++ )
    {
      float fase = omega*float(x+1) - M_PI;
      LUT[x] = atan2f( sinf(fase), cosf(fase) );
    }

  // genera patrones de franjas
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // genera patrones de franjas con ruido
        //float ruido = factor*ruidoImagen.random();
        // Lee valores desde imagen
        float Phase = LUT[IMAGEN.at<unsigned char>(r,c)];
        int idx_r_c = r*columnas + c;
       
        // arreglos con datos de sin y cos de fase ruidosa      
        sn0[idx_r_c] = sinf(Phase);
        cs0[idx_r_c] = cosf(Phase);
       
        Is0_h[idx_r_c] = sn0[idx_r_c];
        Ic0_h[idx_r_c] = cs0[idx_r_c];
        //WP0[idx_r_c] = atan2f(Is0_h[idx_r_c], Ic0_h[idx_r_c]);

        Is_h[idx_r_c] = Is0_h[idx_r_c]; 
        Ic_h[idx_r_c] = Ic0_h[idx_r_c];
//        // calcula el SNR 
//        num += ( (phase+ruido) * (phase+ruido) );
//        den += ( ruido * ruido );
      }

//#ifdef Proc_GPU
  // Copiar memoria del Host al Device
  cudaMemcpy(Is_dev, Is_h, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(Ic_dev, Ic_h, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(WP0_dev, WP0, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(sn0_dev, sn0, size_matrix_bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(cs0_dev, cs0, size_matrix_bytes, cudaMemcpyHostToDevice);
  // Copia del device al device
  cudaMemcpy(Is0_dev, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
  cudaMemcpy(Ic0_dev, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
  cudaMemcpy(Is1_dev, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
  cudaMemcpy(Ic1_dev, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);  

  // ************************************************************************
  //             Inicia procesamiento
  // ************************************************************************
//  struct timeval start, end;      // variables de manejo del tiempo
//  gettimeofday( &start, NULL );    // marca tiempo de inicio 
  float start_time, end_time;
  start_time = (float)cv::getTickCount();

  // variables del metodo
  float epsilon1 = EPSILON1;         // criterio de paro del algoritmo, gradiente
  float epsilon2 = EPSILON2;         // criterio de paro del algoritmo, cambio en x
  unsigned ITER1 = ITER_MAX1;      // maximo de iteraciones 
  unsigned iter = 0;             // contador de iteraciones   
  bool flag = true;

  float error, errIs, errIc;
  //long int SizeImage = renglones*columnas;
  
  // inicia iteracion del algoritmo
//  #ifdef Proc_GPU
  // Copiar memoria del Host al Device
  iter = 0;
  float start_timeFun, end_timeFun;
  float sumTimeFun = 0.0f;
  float start_timeError, end_timeError;
  float sumTimeError = 0.0f;
  start_timeFun = (float)cv::getTickCount();
  float Fx0;

  //Fx0 = Funcional_GPU(Sum_FuncPart, Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, size_Sum_FuncPart, lambda1, lambda2, lambda3, N_threads);
  Fx0 = Funcional_GPU_atomic(Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, sizeof(float), lambda1, lambda2, lambda3, lambda4, lambda5, N_threads);
  
  //cout << "Fx0 : " << Fx0 << endl;

  end_timeFun = (float)cv::getTickCount(); 
  sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency();  
  float sumTime = 0.0f;
  float err[2];
  //flag = false;
  while ( flag )
    {
     // resguarda para calculo de error
     // Copia del device al device
     cudaMemcpy(Is0_dev, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);
     cudaMemcpy(Ic0_dev, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToDevice);

      // calcula iteracion de punto fijo usando Gauss-Seidel
      // retorna solucion actualizada en Is, Ic
      // se promedia tiempo de procesamiento de PF
      float start_timePF, end_timePF;
      start_timePF = (float)cv::getTickCount();
  
      punto_Fijo_TV_GPU(Is_dev, Ic_dev, Is1_dev, Ic1_dev, sn0_dev, cs0_dev, K, renglones, columnas, grid_size_bCond, block_size_FPart, grid_size_FPart, size_matrix_bytes, lambda1, lambda2, lambda3, lambda4, lambda5, BETA); 
      
      end_timePF = (float)cv::getTickCount(); 
      sumTime += (end_timePF - start_timePF) / cv::getTickFrequency();
      
      //P = atan2(Is, Ic);

      start_timeFun = (float)cv::getTickCount();

      //float Fx = Funcional_GPU(Sum_FuncPart, Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, size_Sum_FuncPart, lambda1, lambda2, lambda3, N_threads);
      float Fx = Funcional_GPU_atomic(Sum_FuncPart_dev, Is_dev, Ic_dev, sn0_dev, cs0_dev, renglones, columnas, block_size_evalF, grid_size_evalF, smemSize_FuncPart, sizeof(float), lambda1, lambda2, lambda3, lambda4, lambda5, N_threads);

      //float difF = fabs(Fx0-Fx);    
      end_timeFun = (float)cv::getTickCount(); 
      sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency(); 
            
      Fx0 = Fx;
      
      // calcula error de la estimación, despliega avances
      start_timeError = (float)cv::getTickCount();
      //error_relativo_V2_all_GPU(&errIc, &errIs, Sum_pow2difP_pow2P_pow2P0, Sum_pow2difA_pow2A_pow2A0, Sum_pow2difP_pow2P_pow2P0_dev, Sum_pow2difA_pow2A_pow2A0_dev, Ic_dev, Ic0_dev, Is_dev, Is0_dev, renglones, columnas, grid_size_dif, size_Sum_dif_3, smemSize_3, N_threads);
      error_relativo_V2_all_GPU_atomic(&errIc, &errIs, sum_pow2difRRo_dev,sum_pow2Reo_dev,sum_pow2difIIo_dev,sum_pow2Imo_dev, Ic_dev, Ic0_dev, Is_dev, Is0_dev, renglones, columnas, grid_size_dif, size_Sum_dif_3, smemSize_4, N_threads);
    

      end_timeError = (float)cv::getTickCount();
      sumTimeError += (end_timeError - start_timeError) / cv::getTickFrequency(); 
      if ( (iter % 50) == 0 )
        {
          cout << "iteracion : " << iter << " Fx= " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;

//          dummy = (atan2( Is, Ic ) + M_PI) / (2.0*M_PI);
//          imshow( win1, Imagen );        waitKey( 1 );
        }
        
      // criterios de paro || (difF < epsilon1)
      if ( (iter >= ITER1)  || (errIs < epsilon1) || (errIc < epsilon2))
        {
          cout << "iteracion : " << iter << " Fx = " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;
          flag = false;
        }

      // incrementa contador iteracion
      iter++;
    }
//#endif
  // termina funcion, calcula y despliega valores indicadores del proceso  
//  gettimeofday( &end, NULL );    // marca de fin de tiempo cronometrado  
  end_time = (float)cv::getTickCount(); 

  // ************************************************************************
  //   resultados del procesamiento
  // ************************************************************************

  // calcula tiempo utilizado milisegundos
//  float startms = float(start.tv_sec)*1000. + float(start.tv_usec)/1000.;
//  float endms = float(end.tv_sec)*1000. + float(end.tv_usec)/1000.;
//  float ms = endms - startms;
//    cout << endl << "Tiempo empleado  : " << ms << " mili-segundos" << endl; 
  cout << endl << "Tiempo total : " << (end_time - start_time) / cv::getTickFrequency() << endl;
  cout << endl << "Tiempo promedio PF : " << sumTime/iter << endl;
  cout << endl << "Tiempo promedio funcional  : " << sumTimeFun / (iter+1) << endl; 
  cout << endl << "Tiempo promedio error  : " << sumTimeError / iter << endl; 
//  cout << endl << "Num threads  : " << N_threads << endl; 
  
//#ifdef Proc_GPU
  // Copiar memoria del Device al Host
  cudaMemcpy(Is_h, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Ic_h, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Is0_h, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Ic0_h, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Is1_h, Is_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
  cudaMemcpy(Ic1_h, Ic_dev, size_matrix_bytes, cudaMemcpyDeviceToHost);
//#endif



  cudaFree(Is_dev);
  cudaFree(Ic_dev);
  cudaFree(Is0_dev);
  cudaFree(Ic0_dev);  
  cudaFree(Is1_dev);
  cudaFree(Ic1_dev);  
  cudaFree(WP0_dev); 
  cudaFree(sn0_dev); 
  cudaFree(cs0_dev); 
 
  free(Is_h);
  free(Ic_h);
  free(Is0_h);
  free(Ic0_h);
  free(Is1_h);
  free(Ic1_h);
  free(WP0);
  free(sn0);
  free(cs0);

//  //host memory
//  free(Sum_FuncPart);
//  free(Sum_pow2difP_pow2P_pow2P0);
//  free(Sum_pow2difA_pow2A_pow2A0);
//  free(Sum_pow2difB_pow2B_pow2B0);
//  //Device memory
//  cudaFree(Sum_FuncPart_dev);
//  cudaFree(Sum_pow2difP_pow2P_pow2P0_dev);
//  cudaFree(Sum_pow2difA_pow2A_pow2A0_dev);
//  cudaFree(Sum_pow2difB_pow2B_pow2B0_dev);


  // termina ejecucion del programa
  return 0;
}

