//*************************************************************************
//     * CODIGO SECUENCIAL *
//    Programa que resuelve el modelo para filtrado utilizando punto fijo
//    realiza K iteraciones de Gauss-Seidel con Red & Black
//    Funciones implementadas para arreglos de blitz y tipo double*
//
// Author       : Iván de Jesús May-Cen
// Language     : C++
// Compiler     : g++
// Environment  : 
// Revisions
//   Initial    : 2022-06-29 09:36:44 
//   Last       : 
//
//  para compilar
//    g++ -O2 filtradoPFTVtest.cpp -o test -lrt -lblitz `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//  para ejecutar
//    ./test
//
//  Implementacion sin la libreria BLITZ++
//     02 / Abril / 2023
//
//    g++ -O2 filtradoPFTVtest.cpp -o test -lrt `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//    para ejecutar:
//    ./test Nombre_Archivo_Imagen.png
//    ./test wp480x640-AN-02.png
//
//   para compilar:
//
//  /opt/intel/oneapi/compiler/2023.0.0/linux/bin/icpx -O3 filtradoPFTVtest.cpp -o test_sec_icpx_O3 `pkg-config --cflags opencv` `pkg-config --libs opencv`
//
//    para ejecutar:
//    ./test Nombre_Archivo_Imagen.png
//    ./test wp480x640-AN-02.png
// 
//*************************************************************************

// preprocesor directives
#include <opencv2/core/core.hpp>                // OpenCV      
#include <opencv2/highgui/highgui.hpp>           
#include <sys/time.h>                   // funciones de tiempo
#include <cmath>                        // funciones matematicas
#include <float.h>                      // mathematical constants
#include <iostream>                                  
#include <fstream> 

// declara namespace
using namespace std;
using namespace cv;


// parametros para funcional a utilizar en la optimizacion
const double lambda1 = 1.0;
const double lambda2 = 1.0;
const double lambda3 = 1.0;
//const double CTE = 0.5, factor = 3.0;
const int TIPO = 9, K = 3;
const double BETA = 1.0e-3, EPS0 = 0.01, EPS = sqrt(DBL_EPSILON);

// variables del metodo numerico
const double EPSILON1 = 1.0e-6;         // criterio de paro del algoritmo, gradiente
const double EPSILON2 = 1.0e-6;         // criterio de paro del algoritmo, cambio en x
const unsigned ITER_MAX1 = 200000;    // maximo de iteraciones 


  // datos de la imagen
  int renglones, columnas;
  // variable global para fase ruidosa
  double *sn0, *cs0; 

// declaracion de funciones
double funcionPhase(double,double);
void punto_Fijo_TV( double* Is_h, double* Ic_h, double* Is1_h, double* Ic1_h );
double Funcional( double* Is_h, double* Ic_h );
double gradientWrap(double,double);
double minMod(double,double);  
void boundaryCond1( double* T, int renglones, int columnas );
void boundaryCond1( double* T1, double* T2, int renglones, int columnas );
void eval_Gauss_Seidel_RB(double* Ic_h, double* Is_h, double* Ic1_h, double* Is1_h, int R_B);
void error_relativo(double* errorRe, double* errorIm, double* Re, double* Reo, double* Im, double* Imo);


//*************************************************************************
//
//                        inicia funcion principal
//
//*************************************************************************
int main( int argc, char **argv )
{
  char imgname[50];  //nombre de archivo para imagen ruidosa
  //parametros desde consola
  if(argc = 2) 
    {
     // read name of the file, read image
     strcpy( imgname, argv[1] );
    }
  // despliega informacion del proceso
  cout << endl << "Inicia procesamiento..." << endl << endl;
  cout << endl << "Lee datos ruidosos..." << endl << endl;  

  // datos de la imagen
  Mat IMAGEN = imread(imgname, IMREAD_GRAYSCALE);
  if( !IMAGEN.data )
    {
      cout << "Error en la lectura de la imagen inicial..." << endl;
      return -1;
    }
  renglones = IMAGEN.rows, columnas = IMAGEN.cols;
  
  // Arreglos para calculos numericos
  double *Is_h, *Ic_h, *Is0_h, *Ic0_h, *Is1_h, *Ic1_h;
  long int size_matrix = renglones*columnas;
  size_t size_matrix_bytes = size_matrix * sizeof(double);
  Is_h = (double*)malloc(size_matrix_bytes);
  Ic_h = (double*)malloc(size_matrix_bytes);
  Is0_h = (double*)malloc(size_matrix_bytes);
  Ic0_h = (double*)malloc(size_matrix_bytes);  
  Is1_h = (double*)malloc(size_matrix_bytes);
  Ic1_h = (double*)malloc(size_matrix_bytes);  
  //WP0 = (double*)malloc(size_matrix_bytes); 
  sn0 = (double*)malloc(size_matrix_bytes); 
  cs0 = (double*)malloc(size_matrix_bytes); 
  // crea manejador de imagenes con openCV
  //Mat Imagen( renglones, columnas, CV_64F, (unsigned char*) dummy.data() );
  //const char *win0 = "Fase a recuperar";      namedWindow( win0, WINDOW_AUTOSIZE );
  //const char *win1 = "Estimaciones";          namedWindow( win1, WINDOW_AUTOSIZE );

  // genera patrones de franjas
  int tonos = 256; // tonos de gris
  double omega = 2.0 * M_PI / double(tonos);
  double LUT[tonos];
  for ( int x = 0; x < tonos; x++ )
    {
      double fase = omega*double(x+1) - M_PI;
      LUT[x] = atan2( sin(fase), cos(fase) );
    }

  // genera patrones de franjas
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // genera patrones de franjas con ruido
        //double ruido = factor*ruidoImagen.random();
        // Lee valores desde imagen
        double Phase = LUT[IMAGEN.at<unsigned char>(r,c)];
        int idx_r_c = r*columnas + c;
       
        // arreglos con datos de sin y cos de fase ruidosa      
        sn0[idx_r_c] = sin(Phase);
        cs0[idx_r_c] = cos(Phase);
       
        Is0_h[idx_r_c] = sn0[idx_r_c];
        Ic0_h[idx_r_c] = cs0[idx_r_c];
        //WP0[idx_r_c] = atan2(Is0_h[idx_r_c], Ic0_h[idx_r_c]);

        Is_h[idx_r_c] = Is0_h[idx_r_c]; 
        Ic_h[idx_r_c] = Ic0_h[idx_r_c];
//        // calcula el SNR 
//        num += ( (phase+ruido) * (phase+ruido) );
//        den += ( ruido * ruido );
      }

  // despliega diferencia entre la estimacion y el valor real
//  cout << endl << "SNR = " << 20.0*log10(num/den) << " dB" << endl;

  // despliega valores iniciales
//  dummy = (phase0 - valMin) / (valMax-valMin);
//  dummy = (atan2( sin(phase0), cos(phase0) ) + M_PI) / (2.0*M_PI);  
//  //imshow( win0, Imagen );

//  // guarda imagenes iniciales
//  dummy = (WP + M_PI) / (2.0*M_PI); 
//  imwrite( "imagenes/phaseEnvuelta.pgm", 255*Imagen );
//  dummy = (WP0img + M_PI) / (2.0*M_PI); 
//  imwrite( "imagenes/phaseEnvueltaRuidosa.pgm", 255*Imagen );
//  dummy = Ic0;
//  normalize( Imagen, Imagen, 0, 1, NORM_MINMAX );
//  imwrite( "imagenes/IcRuidosa.pgm", 255*Imagen );
//  dummy = Is0;
//  normalize( Imagen, Imagen, 0, 1, NORM_MINMAX );
//  imwrite( "imagenes/IsRuidosa.pgm", 255*Imagen );

  // ************************************************************************
  //             Inicia procesamiento
  // ************************************************************************
//  struct timeval start, end;      // variables de manejo del tiempo
//  gettimeofday( &start, NULL );    // marca tiempo de inicio 
  double start_time, end_time;
  start_time = (double)cv::getTickCount();

  // variables del metodo
  double epsilon1 = EPSILON1;         // criterio de paro del algoritmo, gradiente
  double epsilon2 = EPSILON2;         // criterio de paro del algoritmo, cambio en x
  unsigned ITER1 = ITER_MAX1;      // maximo de iteraciones 
  unsigned iter = 0;             // contador de iteraciones   
  bool flag = true;

  double error, errIs, errIc;
  long int SizeImage = renglones*columnas;

  // inicia iteracion del algoritmo
  iter = 0;
  double start_timeFun, end_timeFun;
  double sumTimeFun = 0.0;
  double start_timeError, end_timeError;
  double sumTimeError = 0.0;
  start_timeFun = (double)cv::getTickCount();
  double Fx0 = Funcional( Is_h, Ic_h );
  end_timeFun = (double)cv::getTickCount(); 
  sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency();  
  double sumTime = 0.0;

  while ( flag )
    {
      // resguarda para calculo de error
     for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
        {
         Is0_h[idx_r_c] = Is_h[idx_r_c];
         Ic0_h[idx_r_c] = Ic_h[idx_r_c];
        }
      // calcula iteracion de punto fijo usando Gauss-Seidel
      // retorna solucion actualizada en Is, Ic
      // se promedia tiempo de procesamiento de PF
      double start_timePF, end_timePF;
      start_timePF = (double)cv::getTickCount();
      punto_Fijo_TV( Is_h, Ic_h, Is1_h, Ic1_h );
      end_timePF = (double)cv::getTickCount(); 
      sumTime += (end_timePF - start_timePF) / cv::getTickFrequency();
      

      start_timeFun = (double)cv::getTickCount();
      double Fx = Funcional( Is_h, Ic_h );
      end_timeFun = (double)cv::getTickCount(); 
      sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency();    
     
//      double difF = fabs(Fx0-Fx);    

      Fx0 = Fx;

      // calcula error de la estimación, despliega avances
      start_timeError = (double)cv::getTickCount();
      error_relativo(&errIc, &errIs, Ic_h, Ic0_h, Is_h, Is0_h);
      end_timeError = (double)cv::getTickCount();
      sumTimeError += (end_timeError - start_timeError) / cv::getTickFrequency(); 
      if ( (iter % 50) == 0 )
        {
          cout << "iteracion : " << iter << " Fx= " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;

//          dummy = (atan2( Is, Ic ) + M_PI) / (2.0*M_PI);
//          imshow( win1, Imagen );        waitKey( 1 );
        }
        
      // criterios de paro || (difF < epsilon1)
      if ( (iter >= ITER1)  || (errIs < epsilon1) || (errIc < epsilon2))
        {
          cout << "iteracion : " << iter << " Fx = " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;
          flag = false;
        }

      // incrementa contador iteracion
      iter++;
    }

  // termina funcion, calcula y despliega valores indicadores del proceso  
  //gettimeofday( &end, NULL );    // marca de fin de tiempo cronometrado   
  end_time = (double)cv::getTickCount(); 
  // ************************************************************************
  //   resultados del procesamiento
  // ************************************************************************

  // calcula tiempo utilizado milisegundos
//  double startms = double(start.tv_sec)*1000. + double(start.tv_usec)/1000.;
//  double endms = double(end.tv_sec)*1000. + double(end.tv_usec)/1000.;
//  double ms = endms - startms;
//  cout << endl << "Tiempo empleado  : " << ms << " mili-segundos" << endl; 
  cout << endl << "Tiempo total : " << (end_time - start_time) / cv::getTickFrequency() << endl;
  cout << endl << "Tiempo promedio PF : " << sumTime/iter << endl;
  cout << endl << "Tiempo promedio funcional  : " << sumTimeFun / (iter+1) << endl; 
  cout << endl << "Tiempo promedio error  : " << sumTimeError / iter << endl; 
   
  free(Is_h);
  free(Ic_h);
  free(Is0_h);
  free(Ic0_h);
  free(Is1_h);
  free(Ic1_h);
  //free(WP0);
  free(sn0);
  free(cs0);
  // termina ejecucion del programa
  return 0;
}


//*************************************************************************
//
//    Funciones de trabajo
//
//*************************************************************************
//*************************************************************************
//      genera valor de la fase para una posicion
//*************************************************************************
double funcionPhase( double x, double y )
{
  // declara variables de computo
  int tipo = TIPO;
  double phase;
  
  // selecciona termino de fase a utilizar
  switch ( tipo )
    {
      case 0:      // fase simple
        phase = 0.25*M_PI*( x*x + y*y ) / 0.2;
        break;
      case 1:      // fase tomada de la funcion peaks de Matlab
        phase = 5.0*( 3.0*(1.0-x)*(1.0-x)*exp(-x*x - (y+1.0)*(y+1.0)) - 10.0*((x/5.0) - x*x*x - y*y*y*y*y)
                  * exp(-x*x-y*y) - (1.0/3.0)*exp(-(x+1.0)*(x+1.0) - y*y) );
        break;
      case 2:      // fase tomada de la  ec. (24), AppOpt 51, p. 1257
//          x += 0.2;      y += 0.2;
          phase = 0.5*( 2.6 - 3.9*x 
                    - 2.6*( 1.0 - 6.0*y*y - 6.0*x*x + 6.0*y*y*y*y + 12.0*x*x*y*y + 6.0*x*x*x*x )
                    + 6.93*(5.0*x*y*y*y*y - 10.0*x*x*x*y*y + x*x*x*x*x )
                    + 0.86*(3.0*x - 12.0*x*y*y -12.0*x*x*x + 10.0*x*y*y*y*y + 20.0*x*x*x*y*y + 10.0*x*x*x*x*x )
                    + 5.2*(-4.0*y*y*y + 12.0*x*x*y + 5.0*y*y*y*y*y - 10.0*x*x*y*y*y - 15.0*x*x*x*x*y ) );
        break;
      case 3:      // fase tomada de la ec. (31), JOSA A 16, p. 475
        phase = 5.0 - 5.0*( 1.0 - 6.0*y*y - 6.0*x*x + 6.0*y*y*y*y + 12.0*x*x*y*y + 6.0*x*x*x*x )
                  + ( 3.0*x - 12.0*x*y*y - 12.0*x*x*x + 10.0*x*y*y*y*y + 20.0*x*x*x*y*y + 10.0*x*x*x*x*x );
        break;
      case 4:      // fase tomada de la ec. (9), OptLett 22, p. 1669
        phase = 3.0 - 4.5*x - 3.0*( 1.0 - 6.0*y*y - 6.0*x*x + 6.0*y*y*y*y + 12.0*x*x*y*y + 6.0*x*x*x*x )
                  + 8.0*(5.0*x*y*y*y*y - 10.0*x*x*x*y*y + x*x*x*x*x )
                  + (3.0*x - 12.0*x*y*y -12.0*x*x*x + 10.0*x*y*y*y*y + 20.0*x*x*x*y*y + 10.0*x*x*x*x*x )
                  + 6.0*(-4.0*y*y*y + 12.0*x*x*y + 5.0*y*y*y*y*y - 10.0*x*x*y*y*y - 15.0*x*x*x*x*y ); 
        break;
      case 5:      // fase tomada de la  ec. (30), AppOpt 49, p. 6224
          x *= 2.0;       y*= 2.0;
        phase = 2.0*x*y + 4.0*(2.0*(x*x + y*y) - 1.0) + 2.0*(3.0*(x*x + y*y)*y - 2.0*y);
        break;
      case 6:      // fase tomada de la ec. (13),  Proc. SPIE articulo 849319
        x -= 0.5;      
        phase = 45.0*( 2.0*x*y + 8.0*(x*x+y*y) + 6.0*(x*x*x*x+y*y*y*y)*y - 4.0*(y+1) );
        break;
      case 7:      // fase tomada de la ec. (12),  Proc. SPIE articulo 849319
        x -= 0.1;      y -= 0.05;
        phase = 5.0*( 30.0*(x*x + y*y - x*x*x*x - y*y*y*y) - 60.0*x*x*y*y + 3.0*x - 12.0*(x*y*y + x*x*x) 
                 + 10.0*x*y*y*y*y + 20*x*x*x*y*y + 10*x*x*x*x*x );
        break;
      case 8:      // fase tomada de la ec. (11),  Proc. SPIE articulo 849319
        x += 0.2;      y += 0.2;
        phase = 13.75*( -1.5*x + 18.0*(x*x + y*y) - 12.0*y*y*y*y - 36.0*x*x*y*y - 18.0*x*x*x*x
                 + 50.0*x*y*y*y*y - 60.0*x*x*x*y*y + 8.0*x*x*x*x*x -12.0*(x*y*y + x*x*x)
                 + 10.0*x*x*x*x*x - 24.0*y*y*y + 72.0*x*x*y + 30.0*y*y*y*y*y - 60.0*x*x*y*y*y
                 + 90.0*x*x*x*x*y );
        break;

      case 9:      // plano
        phase = 4.0*M_PI*x;
        if ( y < 0.0 )    phase = -1.0*phase - 0.0;
        break;

      case 10:      // plano
        phase = 2.0*M_PI*x;
        break;

      case 11:      // fase tomada de 
        phase = 2.0*2.0*M_PI*( x*x + y*y ) / 0.2;
        if ( x < 0.0 )    phase *= -1.0;
        break;
    }

  // regresa fase
  return phase; 
}


// ************************************************************************
//       funcion para punto fijo para double
//*************************************************************************
void punto_Fijo_TV( double* Is_h, double* Ic_h, double* Is1_h, double* Ic1_h )
{
  // tamano de arreglo
  long int SizeImage = renglones*columnas;

  //condiciones de frontera Neumann para Is, Ic
  boundaryCond1( Ic_h, Is_h, renglones, columnas );

  for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
     {
      Is1_h[idx_r_c] = Is_h[idx_r_c];
      Ic1_h[idx_r_c] = Ic_h[idx_r_c];
     }
  // calculo de punto fijo K iteraciones de GS
  for ( int k = 0; k < K; k++ )
  {
   eval_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 0);
   eval_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 1);
  
   eval_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 0);
   eval_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 1);
                          
//   // actualiza estimacion
//   for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
//     {
//      Is_h[idx_r_c] = Is1_h[idx_r_c];
//      Ic_h[idx_r_c] = Ic1_h[idx_r_c];
//     }
  }

}
// ***************************************************************
//   Gauss-Seidel Red & Black para double
// ***************************************************************
void eval_Gauss_Seidel_RB(double* Ic_h, double* Is_h, double* Ic1_h, double* Is1_h, int R_B)
{
  double auxIm, auxReal, numIm, denIm, numReal, denReal;
  double V1x, V2x, V1y, V2y, Ux, Uy;
  double AIs, BIs, DIs;
  double AIc, BIc, DIc;
  long int SizeImage = renglones*columnas;
  // Paralelizacion de iteracion de Gauss-Seidel-RB
  // Declaracion de variables para region paralela
  // private :
  // firstprivate :  renglones, columnas, R_B, beta, lambda1, lambda2, lambda3
//  #pragma omp parallel for private(auxIm, auxReal, numIm, denIm, numReal, denReal, V1x, V2x, V1y, V2y, Ux, Uy, AIs, BIs, CIs, DIs, AIc, BIc, CIc, DIc) firstprivate(renglones, columnas, R_B, beta, lambda1, lambda2, lambda3) num_threads(N_T)
  for ( int r = 1; r < renglones-1; r++ )
    for ( int c = 1; c < columnas-1; c++ )
      {
        // iteracion de Gauss-Seidel-RB
        //Red & Black (0,1)
        if ((r + c) % 2 == R_B) 
        {  
         long int idx_r_c = r*columnas + c;
	 long int idx_rp1_c = (r + 1)*columnas + c;
	 long int idx_rm1_c = (r - 1)*columnas + c;
	 long int idx_r_cp1 = r*columnas + c + 1;
	 long int idx_r_cm1 = r*columnas + c - 1; 
	 long int idx_rm1_cp1 = (r - 1)*columnas + c + 1; 
	 long int idx_rp1_cm1 = (r + 1)*columnas + c - 1;      
        // procesa condiciones de frontera, eje x
//        if ( r == renglones-1 )
//          { AIs = 0.0; AIc = 0.0; }
//        else
//          {  
            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
            AIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
            AIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//          }  
//        if ( r == 0 )
//          { BIs = 0.0; BIc = 0.0; }
//        else
//          {         
            Ux = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c) - Is(r-1,c);
            Uy = Is_h[idx_rm1_cp1]-Is_h[idx_rm1_c];//Is(r-1,c+1) - Is(r-1,c);
            BIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
            Ux = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c) - Ic(r-1,c);
            Uy = Ic_h[idx_rm1_cp1]-Ic_h[idx_rm1_c];//Ic(r-1,c+1) - Ic(r-1,c);
            BIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//          }  
//      
//        // procesa condiciones de frontera, eje y
//        if ( c == columnas-1 )
//          { CIs = 0.0; CIc = 0.0; }
//        else
//          {          
//            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
//            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
//            CIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
//            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
//            CIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//          }  
//        if ( c == 0 )
//          {  DIs = 0.0; DIc = 0.0;} 
//        else
//          {	     
            Ux = Is_h[idx_rp1_cm1]-Is_h[idx_r_cm1];//Is(r+1,c-1) - Is(r,c-1);
            Uy = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c) - Is(r,c-1);
            DIs = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
            Ux = Ic_h[idx_rp1_cm1]-Ic_h[idx_r_cm1];//Ic(r+1,c-1) - Ic(r,c-1);
            Uy = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c) - Ic(r,c-1);
            DIc = 1.0 / sqrt( Ux*Ux + Uy*Uy + BETA );
//          }
        
        numReal = lambda1*cs0[idx_r_c] + 2.0*lambda3*Ic_h[idx_r_c] + AIc*Ic_h[idx_rp1_c] + BIc*Ic1_h[idx_rm1_c] + AIc*Ic_h[idx_r_cp1] + DIc*Ic1_h[idx_r_cm1];
        numIm = lambda2*sn0[idx_r_c] + 2.0*lambda3*Is_h[idx_r_c] + AIs*Is_h[idx_rp1_c] + BIs*Is1_h[idx_rm1_c] + AIs*Is_h[idx_r_cp1] + DIs*Is1_h[idx_r_cm1];

        auxReal = 2.0*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] ) + lambda1;
        auxIm = 2.0*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] ) + lambda2;
        
        denIm = auxIm + (2.0*AIs + BIs + DIs);
        denReal = auxReal + (2.0*AIc + BIc + DIc);
        Is1_h[idx_r_c] = numIm / denIm;
        Ic1_h[idx_r_c] = numReal / denReal;
        } // fin de if de Red & Black
    } // fin ciclos for
}        


// ***************************************************************
//   min-mod
// ***************************************************************
double minMod( double a, double b )
{
  // minmod operator
  double signa = (a > 0.0) ? 1.0 : ((a < 0.0) ? -1.0 : 0.0);
  double signb = (b > 0.0) ? 1.0 : ((b < 0.0) ? -1.0 : 0.0);
//  double minim = fmin( fabs(a), fabs(b) ); 
  double minim = ( fabs(a) <= fabs(b) ) ? fabs(a) : fabs(b); 
  return ( (signa+signb)*minim/2.0 );

  // geometric average
//  return( 0.5*(a+b) ); Total Variation Diminishing Runge-Kutta Schemes
  
  // upwind 
//  double maxa = (a > 0.0) ? a : 0.0;
//  double maxb = (b > 0.0) ? b : 0.0;
//  return( 0.5*(maxa+maxb) );  
}
// ************************************************************************
//       funcional para double
//*************************************************************************
double Funcional( double* Is_h, double* Ic_h )
{
  // define parametro de regularizacion
  double val = 0.0, v0, v1, v2, v3, a1, a2, a3;
  double dxIs, dyIs, dxIc, dyIc;
  double hx = 1.0 / (double(renglones)-1.0);
  double hy = 1.0 / (double(columnas)-1.0);

  // evalua derivadas parciales para funcional
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // campo de gradiente de la informacion
        if ( c == 0 )
          {  
            long int idx_r_c = r*columnas + c;
            long int idx_r_cp1 = r*columnas + c + 1;
            dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
            dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c); 
           }
        else if ( c == columnas-1 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_r_cm1 = r*columnas + c - 1; 
           dyIs = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c)-Is(r,c-1);
           dyIc = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c)-Ic(r,c-1); 
          }
        else
          {  
           long int idx_r_c = r*columnas + c;
     	   long int idx_r_cp1 = r*columnas + c + 1;      
           dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);//0.5*(Is(r,c+1)-Is(r,c-1)); 
           dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);//0.5*(Ic(r,c+1)-Ic(r,c-1)); }
          }
        // campo de gradiente de la informacion
        if ( r == 0 )
          {  
           long int idx_r_c = r*columnas + c;
	   long int idx_rp1_c = (r + 1)*columnas + c;
           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c)-Is(r,c);
           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c)-Ic(r,c); 
          }
        else if ( r == renglones-1 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_rm1_c = (r - 1)*columnas + c;
           dxIs = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c)-Is(r-1,c);
           dxIc = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c)-Ic(r-1,c);
          }
        else
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_rp1_c = (r + 1)*columnas + c;
           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c)-Is(r,c);//0.5*(Is(r+1,c)-Is(r-1,c)); 
           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c)-Ic(r,c);//0.5*(Ic(r+1,c)-Ic(r-1,c)); 
          }
       // termina calculo de derivadas parciales de fase
       long int idx_r_c = r*columnas + c;
       a1 = Is_h[idx_r_c]-sn0[idx_r_c];
       a2 = Ic_h[idx_r_c]-cs0[idx_r_c];
       a3 = Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] - 1.0;
       v0 = 0.5 * lambda1 * a1*a1 + 0.5 * lambda2 * a2*a2;
       v1 = 0.5 * lambda3 * a3 * a3;
       v2 = sqrt(dxIs*dxIs + dyIs*dyIs);
       v3 = sqrt(dxIc*dxIc + dyIc*dyIc);
       val += v0 + v1 + v2 + v3;
      }

  // regresa valor
  return val * hx * hy;
}

//*************************************************************************
//      obtiene las diferencias envueltas del termino de fase
//*************************************************************************
double gradientWrap( double p1, double p2 )
{
  double r = p1 - p2;
  return atan2( sin(r), cos(r) ); 
}

// ***************************************************************
//   Condiciones de frontera Neumann para double*
// ***************************************************************
void boundaryCond1( double* T, int renglones, int columnas )
{
	// condiciones de frontera
	//T(0, all) = T(1, all);
	//T(renglones - 1, all) = T(renglones - 2, all);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int c = 0; c < columnas; c++){
		long int idx_0_c = c;
		long int idx_1_c = columnas + c;
		long int idx_rm1_c = (renglones - 1)*columnas + c;
		long int idx_rm2_c = (renglones - 2)*columnas + c;

		T[idx_0_c] = T[idx_1_c];
		T[idx_rm1_c] = T[idx_rm2_c];
	}
	//T(all, 0) = T(all, 1);
	//T(all, columnas - 1) = T(all, columnas - 2);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int r = 0; r < renglones; r++){
		long int idx_r_0 = r*columnas;
		long int idx_r_1 = r*columnas + 1;
		long int idx_r_cm1 = r*columnas + columnas - 1;
		long int idx_r_cm2 = r*columnas + columnas - 2;

		T[idx_r_0] = T[idx_r_1];
		T[idx_r_cm1] = T[idx_r_cm2];
	}

	//T(0, 0) = T(1, 1);
	T[0] = T[columnas + 1];
	//T(0, columnas - 1) = T(1, columnas - 2);
	T[columnas - 1] = T[columnas + columnas - 2];
	//T(renglones - 1, 0) = T(renglones - 2, 1);
	T[(renglones - 1)*columnas] = T[(renglones - 2)*columnas + 1];
	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
	T[(renglones - 1)*columnas + columnas - 1] = T[(renglones - 2)*columnas + columnas - 2];
}
// ***************************************************************
//   Condiciones de frontera Neumann para double*, double*
// ***************************************************************
void boundaryCond1( double* T1, double* T2, int renglones, int columnas )
{
	// condiciones de frontera
	//T(0, all) = T(1, all);
	//T(renglones - 1, all) = T(renglones - 2, all);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int c = 0; c < columnas; c++){
		long int idx_0_c = c;
		long int idx_1_c = columnas + c;
		long int idx_rm1_c = (renglones - 1)*columnas + c;
		long int idx_rm2_c = (renglones - 2)*columnas + c;

		T1[idx_0_c] = T1[idx_1_c];
		T1[idx_rm1_c] = T1[idx_rm2_c];
		T2[idx_0_c] = T2[idx_1_c];
		T2[idx_rm1_c] = T2[idx_rm2_c];
	}
	//T(all, 0) = T(all, 1);
	//T(all, columnas - 1) = T(all, columnas - 2);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int r = 0; r < renglones; r++){
		long int idx_r_0 = r*columnas;
		long int idx_r_1 = r*columnas + 1;
		long int idx_r_cm1 = r*columnas + columnas - 1;
		long int idx_r_cm2 = r*columnas + columnas - 2;

		T1[idx_r_0] = T1[idx_r_1];
		T1[idx_r_cm1] = T1[idx_r_cm2];
		T2[idx_r_0] = T2[idx_r_1];
		T2[idx_r_cm1] = T2[idx_r_cm2];
	}

	//T(0, 0) = T(1, 1);
	T1[0] = T1[columnas + 1];
	//T(0, columnas - 1) = T(1, columnas - 2);
	T1[columnas - 1] = T1[columnas + columnas - 2];
	//T(renglones - 1, 0) = T(renglones - 2, 1);
	T1[(renglones - 1)*columnas] = T1[(renglones - 2)*columnas + 1];
	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
	T1[(renglones - 1)*columnas + columnas - 1] = T1[(renglones - 2)*columnas + columnas - 2];
	
	T2[0] = T2[columnas + 1];
	T2[columnas - 1] = T2[columnas + columnas - 2];
	T2[(renglones - 1)*columnas] = T2[(renglones - 2)*columnas + 1];
	T2[(renglones - 1)*columnas + columnas - 1] = T2[(renglones - 2)*columnas + columnas - 2];	
	
}
//***************************************************
// Error relativo para parte real y parte imaginaria
// P = nueva estimacion
// Po = estimacion anterior
//***************************************************
void error_relativo(double* errorRe, double* errorIm, double* Re, double* Reo, double* Im, double* Imo)
{
double sum_pow2difRRo = 0.0, sum_pow2Reo = 0.0, sum_pow2difIIo = 0.0, sum_pow2Imo = 0.0;
long int SizeImage = renglones * columnas;

//#pragma omp parallel for reduction(+:sum_pow2PPo,sum_pow2Po) private(dif) firstprivate(renglones,columnas) num_threads(N_T)
for (int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
  {
   double vRe = Re[idx_r_c];
   double vReo = Reo[idx_r_c];
   double difRe = vRe-vReo;
   sum_pow2difRRo += difRe*difRe;
   sum_pow2Reo += vReo*vReo;  
   double vIm = Im[idx_r_c];
   double vImo = Imo[idx_r_c];
   double difIm = vIm-vImo;
   sum_pow2difIIo += difIm*difIm;
   sum_pow2Imo += vImo*vImo;     
  }

*errorRe = sqrt(sum_pow2difRRo) / sqrt(sum_pow2Reo);
*errorIm = sqrt(sum_pow2difIIo) / sqrt(sum_pow2Imo);
}

