//*************************************************************************
//     * CODIGO SECUENCIAL *
//    Programa que resuelve el modelo para filtrado utilizando punto fijo
//    realiza K iteraciones de Gauss-Seidel con Red & Black
//    Funciones implementadas para arreglos de blitz y tipo float*
//
// Author       : Iván de Jesús May-Cen
// Language     : C++
// Compiler     : g++
// Environment  : 
// Revisions
//   Initial    : 2022-06-29 09:36:44 
//   Last       : 
//
//  para compilar
//    g++ -O2 filtradoPFTVtest.cpp -o test -lrt -lblitz `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//  para ejecutar
//    ./test
//
//  Implementacion sin la libreria BLITZ++
//     02 / Abril / 2023
//
//    g++ -O2 filtradoPFTVtest.cpp -o test -lrt `pkg-config --cflags opencv4` `pkg-config --libs opencv4`
//    para ejecutar:
//    ./test Nombre_Archivo_Imagen.png
//    ./test wp480x640-AN-02.png
//
//   para compilar:
//
//  /opt/intel/oneapi/compiler/2023.0.0/linux/bin/icpx -O3 filtradoPFTVtest.cpp -o test_sec_icpx_O3 `pkg-config --cflags opencv` `pkg-config --libs opencv`
//
//    para ejecutar:
//    ./test Nombre_Archivo_Imagen.png
//    ./test wp480x640-AN-02.png
// 
//*************************************************************************

// preprocesor directives
#include <opencv2/core/core.hpp>                // OpenCV      
#include <opencv2/highgui/highgui.hpp>           
#include <sys/time.h>                   // funciones de tiempo
#include <cmath>                        // funciones matematicas
#include <float.h>                      // mathematical constants
#include <iostream>                                  
#include <fstream> 

// declara namespace
using namespace std;
using namespace cv;


// parametros para funcional a utilizar en la optimizacion
const float lambda1 = 1.0f;
const float lambda2 = 1.0f;
const float lambda3 = 1.0f;
//const float CTE = 0.5, factor = 3.0;
const int TIPO = 9, K = 3;
const float BETA = 1.0e-3f, EPS0 = 0.01f, EPS = sqrtf(DBL_EPSILON);

// variables del metodo numerico
const float EPSILON1 = 1.0e-6f;         // criterio de paro del algoritmo, gradiente
const float EPSILON2 = 1.0e-6f;         // criterio de paro del algoritmo, cambio en x
const unsigned ITER_MAX1 = 200000;    // maximo de iteraciones 


  // datos de la imagen
  int renglones, columnas;
  // variable global para fase ruidosa
  float *sn0, *cs0; 

// declaracion de funciones
float funcionPhase(float,float);
void punto_Fijo_TV( float* Is_h, float* Ic_h, float* Is1_h, float* Ic1_h );
float Funcional( float* Is_h, float* Ic_h );
float gradientWrap(float,float);
float minMod(float,float);  
void boundaryCond1( float* T, int renglones, int columnas );
void boundaryCond1( float* T1, float* T2, int renglones, int columnas );
void eval_Gauss_Seidel_RB(float* Ic_h, float* Is_h, float* Ic1_h, float* Is1_h, int R_B);
void error_relativo(float* errorRe, float* errorIm, float* Re, float* Reo, float* Im, float* Imo);


//*************************************************************************
//
//                        inicia funcion principal
//
//*************************************************************************
int main( int argc, char **argv )
{
  char imgname[50];  //nombre de archivo para imagen ruidosa
  //parametros desde consola
  if(argc = 2) 
    {
     // read name of the file, read image
     strcpy( imgname, argv[1] );
    }
  // despliega informacion del proceso
  cout << endl << "Inicia procesamiento..." << endl << endl;
  cout << endl << "Lee datos ruidosos..." << endl << endl;  

  // datos de la imagen
  Mat IMAGEN = imread(imgname, IMREAD_GRAYSCALE);
  if( !IMAGEN.data )
    {
      cout << "Error en la lectura de la imagen inicial..." << endl;
      return -1;
    }
  renglones = IMAGEN.rows, columnas = IMAGEN.cols;
  
  // Arreglos para calculos numericos
  float *Is_h, *Ic_h, *Is0_h, *Ic0_h, *Is1_h, *Ic1_h;
  long int size_matrix = renglones*columnas;
  size_t size_matrix_bytes = size_matrix * sizeof(float);
  Is_h = (float*)malloc(size_matrix_bytes);
  Ic_h = (float*)malloc(size_matrix_bytes);
  Is0_h = (float*)malloc(size_matrix_bytes);
  Ic0_h = (float*)malloc(size_matrix_bytes);  
  Is1_h = (float*)malloc(size_matrix_bytes);
  Ic1_h = (float*)malloc(size_matrix_bytes);  
  //WP0 = (float*)malloc(size_matrix_bytes); 
  sn0 = (float*)malloc(size_matrix_bytes); 
  cs0 = (float*)malloc(size_matrix_bytes); 
  // crea manejador de imagenes con openCV
  //Mat Imagen( renglones, columnas, CV_64F, (unsigned char*) dummy.data() );
  //const char *win0 = "Fase a recuperar";      namedWindow( win0, WINDOW_AUTOSIZE );
  //const char *win1 = "Estimaciones";          namedWindow( win1, WINDOW_AUTOSIZE );

  // genera patrones de franjas
  int tonos = 256; // tonos de gris
  float omega = 2.0f * M_PI / float(tonos);
  float LUT[tonos];
  for ( int x = 0; x < tonos; x++ )
    {
      float fase = omega*float(x+1) - M_PI;
      LUT[x] = atan2f( sinf(fase), cosf(fase) );
    }

  // genera patrones de franjas
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // genera patrones de franjas con ruido
        //float ruido = factor*ruidoImagen.random();
        // Lee valores desde imagen
        float Phase = LUT[IMAGEN.at<unsigned char>(r,c)];
        int idx_r_c = r*columnas + c;
       
        // arreglos con datos de sin y cos de fase ruidosa      
        sn0[idx_r_c] = sinf(Phase);
        cs0[idx_r_c] = cosf(Phase);
       
        Is0_h[idx_r_c] = sn0[idx_r_c];
        Ic0_h[idx_r_c] = cs0[idx_r_c];
        //WP0[idx_r_c] = atan2(Is0_h[idx_r_c], Ic0_h[idx_r_c]);

        Is_h[idx_r_c] = Is0_h[idx_r_c]; 
        Ic_h[idx_r_c] = Ic0_h[idx_r_c];
//        // calcula el SNR 
//        num += ( (phase+ruido) * (phase+ruido) );
//        den += ( ruido * ruido );
      }

  // despliega diferencia entre la estimacion y el valor real
//  cout << endl << "SNR = " << 20.0*log10(num/den) << " dB" << endl;

  // despliega valores iniciales
//  dummy = (phase0 - valMin) / (valMax-valMin);
//  dummy = (atan2( sin(phase0), cos(phase0) ) + M_PI) / (2.0*M_PI);  
//  //imshow( win0, Imagen );

//  // guarda imagenes iniciales
//  dummy = (WP + M_PI) / (2.0*M_PI); 
//  imwrite( "imagenes/phaseEnvuelta.pgm", 255*Imagen );
//  dummy = (WP0img + M_PI) / (2.0*M_PI); 
//  imwrite( "imagenes/phaseEnvueltaRuidosa.pgm", 255*Imagen );
//  dummy = Ic0;
//  normalize( Imagen, Imagen, 0, 1, NORM_MINMAX );
//  imwrite( "imagenes/IcRuidosa.pgm", 255*Imagen );
//  dummy = Is0;
//  normalize( Imagen, Imagen, 0, 1, NORM_MINMAX );
//  imwrite( "imagenes/IsRuidosa.pgm", 255*Imagen );

  // ************************************************************************
  //             Inicia procesamiento
  // ************************************************************************
//  struct timeval start, end;      // variables de manejo del tiempo
//  gettimeofday( &start, NULL );    // marca tiempo de inicio 
  cout << endl << "Inicia iteraciones..." << endl << endl; 
  float start_time, end_time;
  start_time = (float)cv::getTickCount();

  // variables del metodo
  float epsilon1 = EPSILON1;         // criterio de paro del algoritmo, gradiente
  float epsilon2 = EPSILON2;         // criterio de paro del algoritmo, cambio en x
  unsigned ITER1 = ITER_MAX1;      // maximo de iteraciones 
  unsigned iter = 0;             // contador de iteraciones   
  bool flag = true;

  float error, errIs, errIc;
  long int SizeImage = renglones*columnas;

  // inicia iteracion del algoritmo
  iter = 0;
  float start_timeFun, end_timeFun;
  float sumTimeFun = 0.0f;
  float start_timeError, end_timeError;
  float sumTimeError = 0.0f;
  start_timeFun = (float)cv::getTickCount();
  float Fx0 = Funcional( Is_h, Ic_h );
  end_timeFun = (float)cv::getTickCount(); 
  sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency();  
  float sumTime = 0.0f;

  while ( flag )
    {
      // resguarda para calculo de error
     for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
        {
         Is0_h[idx_r_c] = Is_h[idx_r_c];
         Ic0_h[idx_r_c] = Ic_h[idx_r_c];
        }
      // calcula iteracion de punto fijo usando Gauss-Seidel
      // retorna solucion actualizada en Is, Ic
      // se promedia tiempo de procesamiento de PF
      float start_timePF, end_timePF;
      start_timePF = (float)cv::getTickCount();
      punto_Fijo_TV( Is_h, Ic_h, Is1_h, Ic1_h );
      end_timePF = (float)cv::getTickCount(); 
      sumTime += (end_timePF - start_timePF) / cv::getTickFrequency();
      

      start_timeFun = (float)cv::getTickCount();
      float Fx = Funcional( Is_h, Ic_h );
      end_timeFun = (float)cv::getTickCount(); 
      sumTimeFun += (end_timeFun - start_timeFun) / cv::getTickFrequency();    
     
//      float difF = fabs(Fx0-Fx);    

      Fx0 = Fx;

      // calcula error de la estimación, despliega avances
      start_timeError = (float)cv::getTickCount();
      error_relativo(&errIc, &errIs, Ic_h, Ic0_h, Is_h, Is0_h);
      end_timeError = (float)cv::getTickCount();
      sumTimeError += (end_timeError - start_timeError) / cv::getTickFrequency(); 
      if ( (iter % 50) == 0 )
        {
          cout << "iteracion : " << iter << " Fx= " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;

//          dummy = (atan2( Is, Ic ) + M_PI) / (2.0*M_PI);
//          imshow( win1, Imagen );        waitKey( 1 );
        }
        
      // criterios de paro || (difF < epsilon1)
      if ( (iter >= ITER1)  || (errIs < epsilon1) || (errIc < epsilon2))
        {
          cout << "iteracion : " << iter << " Fx = " << Fx << " ||Is||= " << errIs << " ||Ic||= " << errIc << endl;
          flag = false;
        }

      // incrementa contador iteracion
      iter++;
    }

  // termina funcion, calcula y despliega valores indicadores del proceso  
  //gettimeofday( &end, NULL );    // marca de fin de tiempo cronometrado   
  end_time = (float)cv::getTickCount(); 
  // ************************************************************************
  //   resultados del procesamiento
  // ************************************************************************

  // calcula tiempo utilizado milisegundos
//  float startms = float(start.tv_sec)*1000. + float(start.tv_usec)/1000.;
//  float endms = float(end.tv_sec)*1000. + float(end.tv_usec)/1000.;
//  float ms = endms - startms;
//  cout << endl << "Tiempo empleado  : " << ms << " mili-segundos" << endl; 
  cout << endl << "Tiempo total : " << (end_time - start_time) / cv::getTickFrequency() << endl;
  cout << endl << "Tiempo promedio PF : " << sumTime/iter << endl;
  cout << endl << "Tiempo promedio funcional  : " << sumTimeFun / (iter+1) << endl; 
  cout << endl << "Tiempo promedio error  : " << sumTimeError / iter << endl; 
   
  free(Is_h);
  free(Ic_h);
  free(Is0_h);
  free(Ic0_h);
  free(Is1_h);
  free(Ic1_h);
  //free(WP0);
  free(sn0);
  free(cs0);
  // termina ejecucion del programa
  return 0;
}


//*************************************************************************
//
//    Funciones de trabajo
//
//*************************************************************************
//*************************************************************************
//      genera valor de la fase para una posicion
//*************************************************************************
float funcionPhase( float x, float y )
{
  // declara variables de computo
  int tipo = TIPO;
  float phase;
  
  // selecciona termino de fase a utilizar
  switch ( tipo )
    {
      case 0:      // fase simple
        phase = 0.25f*M_PI*( x*x + y*y ) / 0.2f;
        break;
      case 1:      // fase tomada de la funcion peaks de Matlab
        phase = 5.0f*( 3.0f*(1.0f-x)*(1.0f-x)*expf(-x*x - (y+1.0f)*(y+1.0f)) - 10.0f*((x/5.0f) - x*x*x - y*y*y*y*y)
                  * expf(-x*x-y*y) - (1.0f/3.0f)*expf(-(x+1.0f)*(x+1.0f) - y*y) );
        break;
      case 2:      // fase tomada de la  ec. (24), AppOpt 51, p. 1257
//          x += 0.2;      y += 0.2;
          phase = 0.5f*( 2.6f - 3.9f*x 
                    - 2.6f*( 1.0f - 6.0f*y*y - 6.0f*x*x + 6.0f*y*y*y*y + 12.0f*x*x*y*y + 6.0f*x*x*x*x )
                    + 6.93f*(5.0f*x*y*y*y*y - 10.0f*x*x*x*y*y + x*x*x*x*x )
                    + 0.86f*(3.0f*x - 12.0f*x*y*y -12.0f*x*x*x + 10.0f*x*y*y*y*y + 20.0f*x*x*x*y*y + 10.0f*x*x*x*x*x )
                    + 5.2f*(-4.0f*y*y*y + 12.0f*x*x*y + 5.0f*y*y*y*y*y - 10.0f*x*x*y*y*y - 15.0f*x*x*x*x*y ) );
        break;
      case 3:      // fase tomada de la ec. (31), JOSA A 16, p. 475
        phase = 5.0f - 5.0f*( 1.0f - 6.0f*y*y - 6.0f*x*x + 6.0f*y*y*y*y + 12.0f*x*x*y*y + 6.0f*x*x*x*x )
                  + ( 3.0f*x - 12.0f*x*y*y - 12.0f*x*x*x + 10.0f*x*y*y*y*y + 20.0f*x*x*x*y*y + 10.0f*x*x*x*x*x );
        break;
      case 4:      // fase tomada de la ec. (9), OptLett 22, p. 1669
        phase = 3.0f - 4.5f*x - 3.0f*( 1.0f - 6.0f*y*y - 6.0f*x*x + 6.0f*y*y*y*y + 12.0f*x*x*y*y + 6.0f*x*x*x*x )
                  + 8.0f*(5.0f*x*y*y*y*y - 10.0f*x*x*x*y*y + x*x*x*x*x )
                  + (3.0f*x - 12.0f*x*y*y -12.0f*x*x*x + 10.0f*x*y*y*y*y + 20.0f*x*x*x*y*y + 10.0f*x*x*x*x*x )
                  + 6.0f*(-4.0f*y*y*y + 12.0f*x*x*y + 5.0f*y*y*y*y*y - 10.0f*x*x*y*y*y - 15.0f*x*x*x*x*y ); 
        break;
      case 5:      // fase tomada de la  ec. (30), AppOpt 49, p. 6224
          x *= 2.0f;       y*= 2.0f;
        phase = 2.0f*x*y + 4.0f*(2.0f*(x*x + y*y) - 1.0f) + 2.0f*(3.0f*(x*x + y*y)*y - 2.0f*y);
        break;
      case 6:      // fase tomada de la ec. (13),  Proc. SPIE articulo 849319
        x -= 0.5f;      
        phase = 45.0f*( 2.0f*x*y + 8.0f*(x*x+y*y) + 6.0f*(x*x*x*x+y*y*y*y)*y - 4.0f*(y+1) );
        break;
      case 7:      // fase tomada de la ec. (12),  Proc. SPIE articulo 849319
        x -= 0.1f;      y -= 0.05f;
        phase = 5.0f*( 30.0f*(x*x + y*y - x*x*x*x - y*y*y*y) - 60.0f*x*x*y*y + 3.0f*x - 12.0f*(x*y*y + x*x*x) 
                 + 10.0f*x*y*y*y*y + 20.0f*x*x*x*y*y + 10.0f*x*x*x*x*x );
        break;
      case 8:      // fase tomada de la ec. (11),  Proc. SPIE articulo 849319
        x += 0.2f;      y += 0.2f;
        phase = 13.75f*( -1.5f*x + 18.0f*(x*x + y*y) - 12.0f*y*y*y*y - 36.0f*x*x*y*y - 18.0f*x*x*x*x
                 + 50.0f*x*y*y*y*y - 60.0f*x*x*x*y*y + 8.0f*x*x*x*x*x -12.0f*(x*y*y + x*x*x)
                 + 10.0f*x*x*x*x*x - 24.0f*y*y*y + 72.0f*x*x*y + 30.0f*y*y*y*y*y - 60.0f*x*x*y*y*y
                 + 90.0f*x*x*x*x*y );
        break;

      case 9:      // plano
        phase = 4.0f*M_PI*x;
        if ( y < 0.0f )    phase = -1.0f*phase - 0.0f;
        break;

      case 10:      // plano
        phase = 2.0f*M_PI*x;
        break;

      case 11:      // fase tomada de 
        phase = 2.0f*2.0f*M_PI*( x*x + y*y ) / 0.2f;
        if ( x < 0.0f )    phase *= -1.0f;
        break;
    }

  // regresa fase
  return phase; 
}


// ************************************************************************
//       funcion para punto fijo para float
//*************************************************************************
void punto_Fijo_TV( float* Is_h, float* Ic_h, float* Is1_h, float* Ic1_h )
{
  // tamano de arreglo
  long int SizeImage = renglones*columnas;

  //condiciones de frontera Neumann para Is, Ic
  boundaryCond1( Ic_h, Is_h, renglones, columnas );

  for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
     {
      Is1_h[idx_r_c] = Is_h[idx_r_c];
      Ic1_h[idx_r_c] = Ic_h[idx_r_c];
     }
  // calculo de punto fijo K iteraciones de GS
  for ( int k = 0; k < K; k++ )
  {
   eval_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 0);
   eval_Gauss_Seidel_RB( Ic_h, Is_h, Ic1_h, Is1_h, 1);
  
   eval_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 0);
   eval_Gauss_Seidel_RB( Ic1_h, Is1_h, Ic_h, Is_h, 1);
                          
//   // actualiza estimacion
//   for(int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
//     {
//      Is_h[idx_r_c] = Is1_h[idx_r_c];
//      Ic_h[idx_r_c] = Ic1_h[idx_r_c];
//     }
  }

}
// ***************************************************************
//   Gauss-Seidel Red & Black para float
// ***************************************************************
void eval_Gauss_Seidel_RB(float* Ic_h, float* Is_h, float* Ic1_h, float* Is1_h, int R_B)
{
  float auxIm, auxReal, numIm, denIm, numReal, denReal;
  float V1x, V2x, V1y, V2y, Ux, Uy;
  float AIs, BIs, CIs, DIs;
  float AIc, BIc, CIc, DIc;
  long int SizeImage = renglones*columnas;
  // Paralelizacion de iteracion de Gauss-Seidel-RB
  // Declaracion de variables para region paralela
  // private :
  // firstprivate :  renglones, columnas, R_B, beta, lambda1, lambda2, lambda3
//  #pragma omp parallel for private(auxIm, auxReal, numIm, denIm, numReal, denReal, V1x, V2x, V1y, V2y, Ux, Uy, AIs, BIs, CIs, DIs, AIc, BIc, CIc, DIc) firstprivate(renglones, columnas, R_B, beta, lambda1, lambda2, lambda3) num_threads(N_T)
  for ( int r = 1; r < renglones-1; r++ )
    for ( int c = 1; c < columnas-1; c++ )
      {
        // iteracion de Gauss-Seidel-RB
        //Red & Black (0,1)
        if ((r + c) % 2 == R_B) 
        {  
         long int idx_r_c = r*columnas + c;
	 long int idx_rp1_c = (r + 1)*columnas + c;
	 long int idx_rm1_c = (r - 1)*columnas + c;
	 long int idx_r_cp1 = r*columnas + c + 1;
	 long int idx_r_cm1 = r*columnas + c - 1; 
	 long int idx_rm1_cp1 = (r - 1)*columnas + c + 1; 
	 long int idx_rp1_cm1 = (r + 1)*columnas + c - 1;      
//        // procesa condiciones de frontera, eje x
//        if ( r == renglones-1 )
//          { AIs = 0.0; AIc = 0.0; }
//        else
//          {  
            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
            AIs = 1.0f / sqrtf( Ux*Ux + Uy*Uy + BETA );
            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
            AIc = 1.0f / sqrtf( Ux*Ux + Uy*Uy + BETA );
//          }  
//        if ( r == 0 )
//          { BIs = 0.0; BIc = 0.0; }
//        else
//          {         
            Ux = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c) - Is(r-1,c);
            Uy = Is_h[idx_rm1_cp1]-Is_h[idx_rm1_c];//Is(r-1,c+1) - Is(r-1,c);
            BIs = 1.0f / sqrtf( Ux*Ux + Uy*Uy + BETA );
            Ux = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c) - Ic(r-1,c);
            Uy = Ic_h[idx_rm1_cp1]-Ic_h[idx_rm1_c];//Ic(r-1,c+1) - Ic(r-1,c);
            BIc = 1.0f / sqrtf( Ux*Ux + Uy*Uy + BETA );
//          }  
//      
//        // procesa condiciones de frontera, eje y
//        if ( c == columnas-1 )
//          { CIs = 0.0; CIc = 0.0; }
//        else
//          {    /* AIs = CIs   AIc = CIc */      
//            Ux = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c) - Is(r,c);
//            Uy = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
//            CIs = 1.0 / sqrtf( Ux*Ux + Uy*Uy + BETA );
//            Ux = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c) - Ic(r,c);
//            Uy = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);
//            CIc = 1.0 / sqrtf( Ux*Ux + Uy*Uy + BETA );
//          }  
//        if ( c == 0 )
//          {  DIs = 0.0; DIc = 0.0;} 
//        else
//          {	     
            Ux = Is_h[idx_rp1_cm1]-Is_h[idx_r_cm1];//Is(r+1,c-1) - Is(r,c-1);
            Uy = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c) - Is(r,c-1);
            DIs = 1.0f / sqrtf( Ux*Ux + Uy*Uy + BETA );
            Ux = Ic_h[idx_rp1_cm1]-Ic_h[idx_r_cm1];//Ic(r+1,c-1) - Ic(r,c-1);
            Uy = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c) - Ic(r,c-1);
            DIc = 1.0f / sqrtf( Ux*Ux + Uy*Uy + BETA );
//          }
        
        numReal = lambda1*cs0[idx_r_c] + 2.0f*lambda3*Ic_h[idx_r_c] + AIc*Ic_h[idx_rp1_c] + BIc*Ic1_h[idx_rm1_c] + AIc*Ic_h[idx_r_cp1] + DIc*Ic1_h[idx_r_cm1];
        numIm = lambda2*sn0[idx_r_c] + 2.0f*lambda3*Is_h[idx_r_c] + AIs*Is_h[idx_rp1_c] + BIs*Is1_h[idx_rm1_c] + AIs*Is_h[idx_r_cp1] + DIs*Is1_h[idx_r_cm1];

        auxReal = 2.0f*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] ) + lambda1;
        auxIm = 2.0f*lambda3*( Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] ) + lambda2;
        
        denIm = auxIm + (2.0f*AIs + BIs + DIs);
        denReal = auxReal + (2.0f*AIc + BIc + DIc);
        Is1_h[idx_r_c] = numIm / denIm;
        Ic1_h[idx_r_c] = numReal / denReal;
        } // fin de if de Red & Black
    } // fin ciclos for
}        


// ***************************************************************
//   min-mod
// ***************************************************************
float minMod( float a, float b )
{
  // minmod operator
  float signa = (a > 0.0f) ? 1.0f : ((a < 0.0f) ? -1.0f : 0.0f);
  float signb = (b > 0.0f) ? 1.0f : ((b < 0.0f) ? -1.0f : 0.0f);
//  float minim = fmin( fabs(a), fabs(b) ); 
  float minim = ( fabsf(a) <= fabsf(b) ) ? fabsf(a) : fabsf(b); 
  return ( (signa+signb)*minim/2.0f );

  // geometric average
//  return( 0.5*(a+b) ); Total Variation Diminishing Runge-Kutta Schemes
  
  // upwind 
//  float maxa = (a > 0.0) ? a : 0.0;
//  float maxb = (b > 0.0) ? b : 0.0;
//  return( 0.5*(maxa+maxb) );  
}
// ************************************************************************
//       funcional para float
//*************************************************************************
float Funcional( float* Is_h, float* Ic_h )
{
  // define parametro de regularizacion
  float val = 0.0f, v0, v1, v2, v3, a1, a2, a3;
  float dxIs, dyIs, dxIc, dyIc;
  float hx = 1.0f / (float(renglones)-1.0f);
  float hy = 1.0f / (float(columnas)-1.0f);

  // evalua derivadas parciales para funcional
  for ( int r = 0; r < renglones; r++ )
    for ( int c = 0; c < columnas; c++ )
      {
        // campo de gradiente de la informacion
        if ( c == 0 )
          {  
            long int idx_r_c = r*columnas + c;
            long int idx_r_cp1 = r*columnas + c + 1;
            dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);
            dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c); 
           }
        else if ( c == columnas-1 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_r_cm1 = r*columnas + c - 1; 
           dyIs = Is_h[idx_r_c]-Is_h[idx_r_cm1];//Is(r,c)-Is(r,c-1);
           dyIc = Ic_h[idx_r_c]-Ic_h[idx_r_cm1];//Ic(r,c)-Ic(r,c-1); 
          }
        else
          {  
           long int idx_r_c = r*columnas + c;
     	   long int idx_r_cp1 = r*columnas + c + 1;      
           dyIs = Is_h[idx_r_cp1]-Is_h[idx_r_c];//Is(r,c+1) - Is(r,c);//0.5*(Is(r,c+1)-Is(r,c-1)); 
           dyIc = Ic_h[idx_r_cp1]-Ic_h[idx_r_c];//Ic(r,c+1) - Ic(r,c);//0.5*(Ic(r,c+1)-Ic(r,c-1)); }
          }
        // campo de gradiente de la informacion
        if ( r == 0 )
          {  
           long int idx_r_c = r*columnas + c;
	   long int idx_rp1_c = (r + 1)*columnas + c;
           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c)-Is(r,c);
           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c)-Ic(r,c); 
          }
        else if ( r == renglones-1 )
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_rm1_c = (r - 1)*columnas + c;
           dxIs = Is_h[idx_r_c]-Is_h[idx_rm1_c];//Is(r,c)-Is(r-1,c);
           dxIc = Ic_h[idx_r_c]-Ic_h[idx_rm1_c];//Ic(r,c)-Ic(r-1,c);
          }
        else
          {  
           long int idx_r_c = r*columnas + c;
           long int idx_rp1_c = (r + 1)*columnas + c;
           dxIs = Is_h[idx_rp1_c]-Is_h[idx_r_c];//Is(r+1,c)-Is(r,c);//0.5*(Is(r+1,c)-Is(r-1,c)); 
           dxIc = Ic_h[idx_rp1_c]-Ic_h[idx_r_c];//Ic(r+1,c)-Ic(r,c);//0.5*(Ic(r+1,c)-Ic(r-1,c)); 
          }
       // termina calculo de derivadas parciales de fase
       long int idx_r_c = r*columnas + c;
       a1 = Is_h[idx_r_c]-sn0[idx_r_c];
       a2 = Ic_h[idx_r_c]-cs0[idx_r_c];
       a3 = Is_h[idx_r_c]*Is_h[idx_r_c] + Ic_h[idx_r_c]*Ic_h[idx_r_c] - 1.0f;
       v0 = 0.5f * lambda1 * a1*a1 + 0.5f * lambda2 * a2*a2;
       v1 = 0.5f * lambda3 * a3 * a3;
       v2 = sqrtf(dxIs*dxIs + dyIs*dyIs);
       v3 = sqrtf(dxIc*dxIc + dyIc*dyIc);
       val += v0 + v1 + v2 + v3;
      }

  // regresa valor
  return val * hx * hy;
}

//*************************************************************************
//      obtiene las diferencias envueltas del termino de fase
//*************************************************************************
float gradientWrap( float p1, float p2 )
{
  float r = p1 - p2;
  return atan2f( sinf(r), cosf(r) ); 
}

// ***************************************************************
//   Condiciones de frontera Neumann para float*
// ***************************************************************
void boundaryCond1( float* T, int renglones, int columnas )
{
	// condiciones de frontera
	//T(0, all) = T(1, all);
	//T(renglones - 1, all) = T(renglones - 2, all);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int c = 0; c < columnas; c++){
		long int idx_0_c = c;
		long int idx_1_c = columnas + c;
		long int idx_rm1_c = (renglones - 1)*columnas + c;
		long int idx_rm2_c = (renglones - 2)*columnas + c;

		T[idx_0_c] = T[idx_1_c];
		T[idx_rm1_c] = T[idx_rm2_c];
	}
	//T(all, 0) = T(all, 1);
	//T(all, columnas - 1) = T(all, columnas - 2);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int r = 0; r < renglones; r++){
		long int idx_r_0 = r*columnas;
		long int idx_r_1 = r*columnas + 1;
		long int idx_r_cm1 = r*columnas + columnas - 1;
		long int idx_r_cm2 = r*columnas + columnas - 2;

		T[idx_r_0] = T[idx_r_1];
		T[idx_r_cm1] = T[idx_r_cm2];
	}

	//T(0, 0) = T(1, 1);
	T[0] = T[columnas + 1];
	//T(0, columnas - 1) = T(1, columnas - 2);
	T[columnas - 1] = T[columnas + columnas - 2];
	//T(renglones - 1, 0) = T(renglones - 2, 1);
	T[(renglones - 1)*columnas] = T[(renglones - 2)*columnas + 1];
	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
	T[(renglones - 1)*columnas + columnas - 1] = T[(renglones - 2)*columnas + columnas - 2];
}
// ***************************************************************
//   Condiciones de frontera Neumann para float*, float*
// ***************************************************************
void boundaryCond1( float* T1, float* T2, int renglones, int columnas )
{
	// condiciones de frontera
	//T(0, all) = T(1, all);
	//T(renglones - 1, all) = T(renglones - 2, all);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int c = 0; c < columnas; c++){
		long int idx_0_c = c;
		long int idx_1_c = columnas + c;
		long int idx_rm1_c = (renglones - 1)*columnas + c;
		long int idx_rm2_c = (renglones - 2)*columnas + c;

		T1[idx_0_c] = T1[idx_1_c];
		T1[idx_rm1_c] = T1[idx_rm2_c];
		T2[idx_0_c] = T2[idx_1_c];
		T2[idx_rm1_c] = T2[idx_rm2_c];
	}
	//T(all, 0) = T(all, 1);
	//T(all, columnas - 1) = T(all, columnas - 2);
//#pragma omp parallel for firstprivate(renglones,columnas) num_threads(N_threads)
	for (int r = 0; r < renglones; r++){
		long int idx_r_0 = r*columnas;
		long int idx_r_1 = r*columnas + 1;
		long int idx_r_cm1 = r*columnas + columnas - 1;
		long int idx_r_cm2 = r*columnas + columnas - 2;

		T1[idx_r_0] = T1[idx_r_1];
		T1[idx_r_cm1] = T1[idx_r_cm2];
		T2[idx_r_0] = T2[idx_r_1];
		T2[idx_r_cm1] = T2[idx_r_cm2];
	}

	//T(0, 0) = T(1, 1);
	T1[0] = T1[columnas + 1];
	//T(0, columnas - 1) = T(1, columnas - 2);
	T1[columnas - 1] = T1[columnas + columnas - 2];
	//T(renglones - 1, 0) = T(renglones - 2, 1);
	T1[(renglones - 1)*columnas] = T1[(renglones - 2)*columnas + 1];
	//T(renglones - 1, columnas - 1) = T(renglones - 2, columnas - 2);
	T1[(renglones - 1)*columnas + columnas - 1] = T1[(renglones - 2)*columnas + columnas - 2];
	
	T2[0] = T2[columnas + 1];
	T2[columnas - 1] = T2[columnas + columnas - 2];
	T2[(renglones - 1)*columnas] = T2[(renglones - 2)*columnas + 1];
	T2[(renglones - 1)*columnas + columnas - 1] = T2[(renglones - 2)*columnas + columnas - 2];	
	
}
//***************************************************
// Error relativo para parte real y parte imaginaria
// P = nueva estimacion
// Po = estimacion anterior
//***************************************************
void error_relativo(float* errorRe, float* errorIm, float* Re, float* Reo, float* Im, float* Imo)
{
float sum_pow2difRRo = 0.0f, sum_pow2Reo = 0.0f, sum_pow2difIIo = 0.0f, sum_pow2Imo = 0.0f;
long int SizeImage = renglones * columnas;

//#pragma omp parallel for reduction(+:sum_pow2PPo,sum_pow2Po) private(dif) firstprivate(renglones,columnas) num_threads(N_T)
for (int idx_r_c = 0; idx_r_c < SizeImage; idx_r_c++) 
  {
   float vRe = Re[idx_r_c];
   float vReo = Reo[idx_r_c];
   float difRe = vRe-vReo;
   sum_pow2difRRo += difRe*difRe;
   sum_pow2Reo += vReo*vReo;  
   float vIm = Im[idx_r_c];
   float vImo = Imo[idx_r_c];
   float difIm = vIm-vImo;
   sum_pow2difIIo += difIm*difIm;
   sum_pow2Imo += vImo*vImo;     
  }

*errorRe = sqrtf(sum_pow2difRRo) / sqrtf(sum_pow2Reo);
*errorIm = sqrtf(sum_pow2difIIo) / sqrtf(sum_pow2Imo);
}

